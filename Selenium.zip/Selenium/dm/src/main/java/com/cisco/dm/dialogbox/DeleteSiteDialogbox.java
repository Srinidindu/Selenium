package com.cisco.dm.dialogbox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DefaultPage;

/**
 * A delete site dialogbox class.
 * 
 * @author nochin
 *
 */
public class DeleteSiteDialogbox extends DefaultPage 
{
	@FindBy(xpath = DMConstants.DIALOGBOX_DELETE_SITE_MESSAGE)
	private WebElement message;	
	@FindBy(xpath = DMConstants.DIALOGBOX_DELETE_SITE_YES_BUTTON)
	private WebElement yesButton;	
	@FindBy(xpath = DMConstants.DIALOGBOX_DELETE_SITE_NO_BUTTON)
	private WebElement noButton;	

	public DeleteSiteDialogbox(WebDriver driver, String url) 
	{
		super(driver, url);
	}
	
	/**
	 * Gets the WebElement of the message element on the dialogbox.
	 * 
	 * @return	a WebElement object.
	 */
	public WebElement getMessageElement()
	{
		return this.message;
	}

	/**
	 * Gets the Yes button WebElement on the dialogbox.
	 * 
	 * @return	a WebElement object of the Yes button.
	 */
	public WebElement getYesButtonElement()
	{
		return this.yesButton;
	}

	/**
	 * Gets the No button WebElement on the dialogbox.
	 * 
	 * @return	a WebElement object of the No button.
	 */
	public WebElement getNoButtonElement()
	{
		return this.noButton;
	}
	
	/**
	 * Selects the Yes button.
	 */
	public void selectYes()
	{
		getYesButtonElement().click();
	}
	
	/**
	 * Selects the No button.
	 */
	public void selectNo()
	{
		getNoButtonElement().click();
	}
}
