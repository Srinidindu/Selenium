package com.cisco.dm.dialogbox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DefaultPage;
import com.cisco.dm.util.Wait;

/**
 * A confirm logout dialogbox class. This class is extended from LoadableModule so
 * you need to issue a "get" to load the elements into this class.
 * 
 * @author nochin
 *
 */
public class ConfirmLogoutDialogbox extends DefaultPage
{
	@FindBy(xpath = DMConstants.DIALOGBOX_CONFIRM_TITLE)
	private WebElement title;	
	@FindBy(xpath = DMConstants.DIALOGBOX_CONFIRM_MESSAGE)
	private WebElement message;	
	@FindBy(xpath = DMConstants.DIALOGBOX_CONFIRM_YES_BUTTON)
	private WebElement yesButton;	
	@FindBy(xpath = DMConstants.DIALOGBOX_CONFIRM_NO_BUTTON)
	private WebElement noButton;	

	public ConfirmLogoutDialogbox(WebDriver driver, String url) 
	{
		super(driver, url);
	}
	
	public WebElement getTitleElement() {
		return this.title;
	}

	public WebElement getMessageElement()
	{
		return this.message;
	}
	
	public WebElement getYesButtonElement()
	{
		return this.yesButton;
	}
		
	public void selectYes()
	{
		WebElement yesB = getYesButtonElement();
		
		Wait.forElementToBeClickable(driver, yesB, 30);
		yesB.click();
	}
		
	public WebElement getNoButtonElement()
	{
		return this.noButton;
	}
	
	public void selectNo()
	{
		getNoButtonElement().click();
	}
}
