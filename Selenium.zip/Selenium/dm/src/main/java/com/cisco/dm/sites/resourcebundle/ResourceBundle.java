package com.cisco.dm.sites.resourcebundle;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DMUtils;
import com.cisco.dm.util.DefaultHeaderPage;

/**
 * This class contains methods for user actions on Site page
 * 
 * @author sdindu
 * 
 */
public class ResourceBundle extends DefaultHeaderPage {

	@FindBy(xpath = DMConstants.RESOURCE_BUNDLE_COPY_BUTTON)
	private WebElement copyButton;

	public ResourceBundle(WebDriver driver, String url) {
		super(driver, url + "#sites");
	}

	public void addResourceBundle(String name, String annotation)
			throws Exception {
		// click add resource bundle button
		driver.findElement(
				By.xpath(DMConstants.XPATH_ADD_RESOURCE_BUNDLE_BUTTON)).click();
		Thread.sleep(2000);

		// enter name details
		driver.findElement(By.xpath(DMConstants.XPATH_NAME_FIELD)).sendKeys(
				name);

		// enter annotation details
		driver.findElement(By.xpath(DMConstants.XPATH_ANNOTATION_FIELD))
				.sendKeys(annotation);

		// click add bundle button
		driver.findElement(By.xpath(DMConstants.XPATH_ADD_BUNDLE_BUTTON))
				.click();
	}

	public void addResourceToResourceBundle(String resourcePath,
			String resourceBundle) throws InterruptedException {
		Thread.sleep(8000);
		DMUtils.doubleClick(driver,
				driver.findElement(By.xpath(".//div[@title='shared']")));
		Thread.sleep(6000);
		driver.findElement(By.xpath(".//div[@title='Source_RS']")).click();
		Thread.sleep(6000);
		driver.findElement(By.xpath(".//div[text()='Add Resources to ']"))
				.click();
		Thread.sleep(6000);
		driver.findElement(
				By.xpath(".//span[text()='TEST_RESOURCE_BUNDLE' and @unselectable='on']"))
				.click();
	}

	private String getResourceNodeXpath(String resourceName) {
		return new StringBuffer(DMConstants.XPATH_RESOURCE_NODE).replace(
				DMConstants.XPATH_RESOURCE_NODE.indexOf("<"),
				DMConstants.XPATH_RESOURCE_NODE.indexOf(">") + 1, resourceName)
				.toString();
	}

	private String getResourceBundleMenuItemXpath(String resourceBundleName) {
		return new StringBuffer(DMConstants.XPATH_RESOURCE_BUNDLE_NODE)
				.replace(
						DMConstants.XPATH_RESOURCE_BUNDLE_NODE.indexOf("<"),
						DMConstants.XPATH_RESOURCE_BUNDLE_NODE.indexOf(">") + 1,
						resourceBundleName).toString();

	}

	public String getResourceBundlePath() {
		return driver.findElement(By.xpath(".//div[@id='x-auto-30']"))
				.getAttribute("title");
	}

	public void clickCopyResourceBundle() {

	}
}
