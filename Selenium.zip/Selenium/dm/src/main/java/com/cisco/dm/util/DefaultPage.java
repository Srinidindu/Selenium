package com.cisco.dm.util;

import static org.testng.Assert.assertTrue;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;

/**
 *
 * A base class to handle a Page Object. When the constructor is called, the elements
 * with FindBy annotations are initialized to WebElements. This is done with call to
 * the PageFactory initElements method in the constructor. If no FindBy annotations
 * are present, then no action is taken.
 * 
 * @author nochin
 */
public class DefaultPage extends LoadableComponent <DefaultPage> {
	@FindBy(xpath = DMConstants.FOOTER_PRODUCT_TITLE)
	private WebElement productTitle;	
	@FindBy(xpath = DMConstants.FOOTER_COPYRIGHT)
	private WebElement copyright;	
	@FindBy(xpath = DMConstants.STATUS_LOADING)
	private WebElement loadingStatus;	

	protected String BASE_URL;
	protected final WebDriver driver;
	
	/**
	 * A DefaultPage constructor.
	 * 
	 * @param driver	The WebDriver object.
	 * @param url		The page url.
	 */
	public DefaultPage(WebDriver driver, String url)
	{
		this.driver = driver;
		this.driver.manage().window().maximize();
		PageFactory.initElements(driver, this);
		
		try {
			URL aURL = new URL(url);
			String redir_port = String.valueOf(aURL.getPort());
			
			// Get the new redirected url.
			this.BASE_URL = "https://"+aURL.getHost()+":"+(redir_port.substring(0,3))+"2"+aURL.getPath();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void load() 
	{
		//logger.info("DefaultPage: load()");
		this.driver.get(this.BASE_URL);
	}

	@Override
	protected void isLoaded() throws Error 
	{
		//logger.info("DefaultPage: isLoaded()");
		String url = this.driver.getCurrentUrl();
		assertTrue(url.startsWith(this.BASE_URL), "Expected url to start with "+ BASE_URL + " but was " + url);		
		
		Wait.forVisibilityLocatedBy(driver, By.xpath(DMConstants.FOOTER_COPYRIGHT), 15);
	}
	
	/**
	 * Gets the loading status Web element.
	 * 
	 * @return	the loading status Web element.
	 */
	public WebElement getLoadingStatusElement() {
		return this.loadingStatus;
	}

	/**
	 * Gets the Loading status locator object.
	 * @return	the locator object.
	 */
	public By getLoadingStatusLocator() {
		return By.xpath(DMConstants.STATUS_LOADING);
	}

	/**
	 * Gets the Copyright Web element.
	 * @return	the Copyright Web element.
	 */
	public WebElement getCopyrightElement() {
		return this.copyright;
	}

	/**
	 * Gets the footer product title Web element.
	 * @return	the product title Web element.
	 */
	public WebElement getProductTitleElement() {
		return this.productTitle;
	}

	/**
	 * Sends a key sequence to the Web element (input element).
	 * This method does not clear the input field before sending the key sequences.
	 * 
	 * @param elem	the WebElement object.
	 * @param keysToSend	a string containing the key sequences to send.
	 */
	public void sendKeys(WebElement elem, String keysToSend)
	{
		sendKeys(elem, keysToSend, false);
	}
	
	/**
	 * Sends a key sequence to the Web element (input element) and the option
	 * to clear the input field first.
	 * 
	 * @param elem	the WebElement object.
	 * @param keysToSend	a string containing the key sequences to send.
	 * @param clear	a boolean value to specify to clear or not to clear before sending the key sequences.
	 */
	public void sendKeys(WebElement elem, String keysToSend, boolean clear)
	{
		if (clear)
			elem.clear();
		elem.sendKeys(keysToSend);
	}

	/**
	 * Perform a single mouse click.
	 * 
	 * @param elem	the WebElement to be clicked on.
	 */
	public void performClick(WebElement elem)
	{
		Actions action = new Actions(this.driver);
		action.moveToElement(elem).click().perform();
	}

	/**
	 * Perform a double mouse click.
	 * 
	 * @param elem	the WebElement to be performed on.
	 */
	public void performDoubleClick(WebElement elem)
	{
		Actions action = new Actions(this.driver);
		action.moveToElement(elem).doubleClick().perform();
	}
	
	/**
	 * Perform a mouse hovering over an element.
	 * 
	 * @param elem	the WebElement to be moved to and hover over.
	 */
	public void performMove(WebElement elem)
	{
		Actions builder = new Actions(driver);
		builder.moveToElement(elem).perform();
	}
	
	/**
	 * Perform a mouse hovering over a location relative to the element.
	 * 
	 * @param elem	a WebElement to be performed on.
	 * @param xOffset	an integer value representing the horizontal offset.
	 * @param yOffset	an integer value representing the vertical offset.
	 */
	public void performMove(WebElement elem, int xOffset, int yOffset)
	{
		Actions builder = new Actions(driver);
		builder.moveToElement(elem, xOffset, yOffset).perform();
	}
	
	/**
	 * Gets the current element which has the focus. The cursor position is also
	 * set to this element if you need to determine the current cursor position. It may
	 * return 0,0 which mean there is no focus on a particular element.
	 * 
	 * @return	a WebElement object.
	 */
	public WebElement getFocusedElement() {
		return (WebElement)((JavascriptExecutor)this.driver).executeScript("return document.activeElement;");		
	}

}
