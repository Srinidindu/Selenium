package com.cisco.dm.util;

import java.io.File;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;

/**
 * A driver factory class to create a generic WebDriver object depending on the browser
 * string passed into the initDriver method.
 * 
 * @author nochin
 *
 */
public class DriverFactory {
	//public static WebDriver driver;	// Use this if singleton is required.
    private static final Logger logger = LogManager.getLogger("DriverFactory");

	// Prevents any other class from instantiating.
	private DriverFactory() {}
	
	/**
	 * @param browser	The browser name. Supported browsers are Chrome, Firefox, InternetExplorer and Safari.
	 * @return			The WebDriver instance.
	 * @throws Exception	if browser name is invalid.
	 */
	public static WebDriver initDriver(String browser) throws Exception
	{
		// Assumes current working directory has resources directory containing the web driver executables.
		StringBuilder pathToDriver = new StringBuilder("src"+File.separatorChar+"test"+File.separatorChar+"resources");
		
		WebDriver driver = null;
		if (!OSValidator.isSupportedPlatform())
			throw new Exception("Unsupported OS to run driver.");
		switch (browser.toLowerCase())
		{
			case "chrome":
				if (OSValidator.isMac())
					System.setProperty("webdriver.chrome.driver", pathToDriver.toString()+File.separatorChar+"chromedriver");
				else if (OSValidator.isWindows())
					System.setProperty("webdriver.chrome.driver", pathToDriver.toString()+File.separatorChar+"chromedriver.exe");

				logger.info("Starting Chrome browser.");
				driver = new ChromeDriver();
				break;
			case "ff":
			case "firefox":
				logger.info("Starting Firefox browser.");
				driver = new FirefoxDriver();
				break;
			case "safari":
				//System.setProperty("webdriver.safari.driver", pathToDriver.toString());
				//System.setProperty("webdriver.safari.noinstall", "true");
				logger.info("Starting Safari browser.");
				driver = new SafariDriver();
				break;
			case "ie":
			case "internetexplorer":
				// TODO:: Determine 32 bit or 64 bit driver to use.
				// Note: IE10 has issue with 64 bit driver. Maybe safer to use on 32 bit with IE running 32 bit.
				logger.info("Starting IE browser.");
				System.setProperty("webdriver.ie.driver", pathToDriver.toString()+File.separatorChar+"IEDriverServer.exe");
				driver = new InternetExplorerDriver();
				break;
			default:
				throw new Exception("Browser name ("+browser+") is invalid.");
		}
		return driver;
	}
}
