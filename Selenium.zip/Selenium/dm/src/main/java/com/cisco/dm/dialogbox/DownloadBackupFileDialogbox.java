package com.cisco.dm.dialogbox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DefaultPage;

/**
 * A class to handle the Download Backup File dialogbox.
 * 
 * @author nochin
 *
 */
public class DownloadBackupFileDialogbox extends DefaultPage {
	@FindBy(xpath = DMConstants.DIALOGBOX_BACKUP_TITLE)
	private WebElement title;	
	@FindBy(xpath = DMConstants.DIALOGBOX_BACKUP_MESSAGE)
	private WebElement message;	
	@FindBy(xpath = DMConstants.DIALOGBOX_BACKUP_DOWNLOAD_BUTTON)
	private WebElement downloadButton;	
	@FindBy(xpath = DMConstants.DIALOGBOX_BACKUP_CANCEL_BUTTON)
	private WebElement cancelButton;	

	public DownloadBackupFileDialogbox(WebDriver driver, String url) {
		super(driver, url);
	}

	/**
	 * Gets the WebElement of the dialogbox title.
	 * 
	 * @return	the WebElement object.
	 */
	public WebElement getTitleElement() {
		return this.title;
	}

	/**
	 * Gets the dialogbox message WebElement.
	 * 
	 * @return	the WebElement object.
	 */
	public WebElement getMessageElement() {
		return this.message;
	}

	/**
	 * Gets the Download button WebElement.
	 * 
	 * @return	the WebElement object.
	 */
	public WebElement getDownloadButtonElement() {
		return this.downloadButton;
	}

	/**
	 * Gets the Cancel button WebElement.
	 * 
	 * @return	the WebElement object.
	 */
	public WebElement getCancelButtonElement() {
		return this.cancelButton;
	}
	
	/**
	 * Selects the Cancel button.
	 */
	public void selectCancel() {
		getCancelButtonElement().click();
	}
	
	/**
	 * Selects the Download button.
	 */
	public void selectDownload() {
		this.getDownloadButtonElement().click();
	}
}
