package com.cisco.dm;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.testng.log4testng.Logger;

import com.cisco.dm.plans.PlanPage;
import com.cisco.dm.sites.SitePage;
import com.cisco.dm.sites.resourcebundle.ResourceBundle;
import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DefaultHeaderPage;

public class DMPage extends DefaultHeaderPage {

	public DMPage(WebDriver driver, String url) {
		super(driver, url);
	}

	public static Logger logger = Logger.getLogger(DMPage.class);

	/**
	 * This method is used to login to deployment manager UI using given
	 * credentials: DOMAIN, USERNAME and PASSWORD
	 * 
	 * @param driver
	 * @param domain
	 * @param username
	 * @param password
	 * @throws Exception
	 */
	public static void login(WebDriver driver, String domain, String username,
			String password) throws Exception {
		LoginPage loginPage = new LoginPage(driver, password);
		System.out
				.println(DMConstants.SYSOUT_MSG_LOGGING_TO_DM_USING_CREDENTIALS);
		System.out.format(DMConstants.SYSOUT_DOMAIN_USERNAME_PASSWORD, domain,
				username, password);
		loginPage.login(domain, username, password);

	}

	/**
	 * This method is used to add a site
	 * 
	 * @param driver
	 * @param host
	 * @param port
	 * @param domain
	 * @param username
	 * @param password
	 * @param annotation
	 */
	public static void addSite(WebDriver driver, String host, Integer port,
			String domain, String username, String password, String annotation) {
		SitePage sitePage = new SitePage(driver, annotation);
		// sitePage.addsite(host, port, domain, username, password, annotation);
	}

	public static void selectSite(WebDriver driver, String siteName)
			throws Exception {
		try {
			new SitePage(driver, siteName).selectSite(siteName);
		} catch (StaleElementReferenceException e) {
			Thread.sleep(4000);
			new SitePage(driver, siteName).selectSite(siteName);
		}
	}

	/**
	 * This method is used to add resource bundle
	 * 
	 * @param driver
	 * @param resourecBundlename
	 * @param annotation
	 * @throws Exception
	 */
	public static void addResourceBundle(WebDriver driver,
			String resourecBundleName, String resourceBundleAnnotation)
			throws Exception {
		ResourceBundle resourceBundle = new ResourceBundle(driver, "");
		resourceBundle.addResourceBundle(resourecBundleName,
				resourceBundleAnnotation);
	}

	/**
	 * This method is use to map resource to resource bundle
	 * 
	 * @param driver
	 * @param resourcePath
	 * @param resourecBundle
	 * @throws Exception
	 */
	public static void addResourceToResourceBundle(WebDriver driver,
			String resourcePath, String resourecBundle) throws Exception {
		ResourceBundle resourceBundle = new ResourceBundle(driver,
				resourecBundle);
		resourceBundle
				.addResourceToResourceBundle(resourcePath, resourecBundle);
	}

	/**
	 * This method is used to delete the site with a given name
	 * 
	 * @param driver
	 * @param siteName
	 * @throws Exception
	 */
	public static void deleteSite(WebDriver driver, String siteName)
			throws Exception {
		try {
			new SitePage(driver, siteName).deleteSite(siteName);
		} catch (StaleElementReferenceException e) {
			Thread.sleep(4000);
			new SitePage(driver, siteName).deleteSite(siteName);
		}
	}

	/**
	 * This method is used to add a plan
	 * 
	 * @param driver
	 * @param planName
	 * @param description
	 * @param sourceSiteName
	 * @param targetSiteName
	 * @throws Exception
	 */
	public static void addPlan(WebDriver driver, String planName,
			String description, String sourceSiteName, String targetSiteName)
			throws Exception {
		new PlanPage(driver, "").addPlan(planName, description, sourceSiteName,
				targetSiteName);
	}

	public static void addMigrateOperation(WebDriver driver, String planName,
			String resourceBundleName, String targetLocation)
			throws InterruptedException {
		new PlanPage(driver, "").addMigrateOperation(planName,
				resourceBundleName, targetLocation);
	}

	public static void executePlan(WebDriver driver, String planName)
			throws Exception {
		try {
			new PlanPage(driver, "").executePlan(planName);
		} catch (StaleElementReferenceException e) {
			Thread.sleep(4000);
			new PlanPage(driver, "").executePlan(planName);
		}
	}

	/**
	 * This method is used to logout of the deployment manager UI
	 * 
	 * @param driver
	 * @throws InterruptedException
	 */
	public static void logout(WebDriver driver) throws InterruptedException {
		LoginPage loginPage = new LoginPage(driver, null);
		logger.info(DMConstants.SYSOUT_MSG_LOGGING_OUT);
		HomePage homePage = new HomePage(driver, "");
		homePage.logout();
		logger.info(DMConstants.SYSOUT_MSG_LOGGED_OUT_SUCCESSFULLY);
	}

}
