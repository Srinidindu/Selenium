package com.cisco.dm.sites;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.cisco.dm.dialogbox.AddSiteDialogbox;
import com.cisco.dm.dialogbox.DeleteSiteDialogbox;
import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DefaultHeaderPage;
import com.cisco.dm.util.Wait;

/**
 * A class to handle sites.
 * 
 * @author nochin
 * 
 */
public class SitePage extends DefaultHeaderPage {

	@FindBy(xpath = DMConstants.SITE_PAGE_SITE_LIST)
	private WebElement siteList;
	@FindBy(xpath = DMConstants.SITE_PAGE_SITE_LIST_PANEL)
	private WebElement siteListPanel;
	@FindBy(xpath = DMConstants.SITE_PAGE_ADD_BUTTON)
	private WebElement addButton;
	@FindBy(xpath = DMConstants.SITE_PAGE_DELETE_BUTTON)
	private WebElement deleteButton;
	@FindBy(xpath = DMConstants.SITE_PAGE_REFRESH_BUTTON)
	private WebElement refreshButton;
	@FindBy(xpath = DMConstants.SITE_PAGE_SITE_DETAILS_TAB_CONTROLS)
	private WebElement tabControls;
	@FindBy(xpath = DMConstants.SITE_PAGE_SITE_DETAILS_TAB_RESOURCE_BUNDLES)
	private WebElement resourceBundleTab;
	@FindBy(xpath = DMConstants.SITE_PAGE_SITE_DETAILS_TAB_PRINCIPAL_BUNDLES)
	private WebElement principalBundleTab;
	@FindBy(xpath = DMConstants.SITE_PAGE_SITE_DETAILS_TAB_RESOURCE_MAPPINGS)
	private WebElement resourceMappingsTab;
	@FindBy(xpath = DMConstants.SITE_PAGE_SITE_DETAILS_TAB_PRINCIPAL_MAPPINGS)
	private WebElement principalMappingsTab;
	@FindBy(xpath = DMConstants.STATUS_REFRESHING_SITES)
	private WebElement refreshStatus;

	public SitePage(WebDriver driver, String url) {
		super(driver, url + "#sites");
	}

	public WebElement getSiteListElement() {
		return this.siteList;
	}

	public WebElement getAddButtonElement() {
		return this.addButton;
	}

	public WebElement getDeleteButtonElement() {
		return this.deleteButton;
	}

	public WebElement getRefreshButtonElement() {
		return this.refreshButton;
	}

	public WebElement getPrincipalMappingsTabElement() {
		return this.principalMappingsTab;
	}

	public WebElement getResourceBundleTabElement() {
		return this.resourceBundleTab;
	}

	public WebElement getPrincipalBundleTabElement() {
		return this.principalBundleTab;
	}

	public WebElement getResourceMappingsTabElement() {
		return this.resourceMappingsTab;
	}

	public WebElement getSiteListPanelELement() {
		return this.siteListPanel;
	}

	/**
	 * Gets the Refresh popup status message when the Refresh button is
	 * selected. This element is defined in the initial page but is set to
	 * non-displayable until the refresh button is selected.
	 * 
	 * @return the Refresh status WebElement.
	 */
	public WebElement getRefreshStatusElement() {
		return this.refreshStatus;
	}

	public void selectAdd() {
		this.getAddButtonElement().click();
	}

	public void selectDelete() {
		this.getDeleteButtonElement().click();
	}

	public void selectRefresh() {
		this.getRefreshButtonElement().click();
	}

	/**
	 * Selects the tab by the tab name in the Site Detail section.
	 * 
	 * @param tabName
	 *            the textual name of the tab.
	 */
	public void selectSiteDetailTab(String tabName) {
		this.tabControls.findElement(
				By.xpath("./li//span[contains(text(), '" + tabName + "')]"))
				.click();
		;
	}

	/**
	 * Adds a site with the specified parameters (host, port, domain, user name
	 * and password).
	 * 
	 * @param host
	 *            the host name.
	 * @param port
	 *            the port number.
	 * @param domain
	 *            the domain name.
	 * @param username
	 *            the user name.
	 * @param password
	 *            the password.
	 * @param annotation
	 *            the annotation text.
	 */
	public void addSite(String host, String port, String domain,
			String username, String password, String annotation) {
		this.addButton.click();

		AddSiteDialogbox addSiteDialog = new AddSiteDialogbox(driver,
				this.BASE_URL);
		addSiteDialog.setHost(host);
		addSiteDialog.setPort(port);
		addSiteDialog.setDomain(domain);
		addSiteDialog.setUser(username);
		addSiteDialog.setPassword(password);
		addSiteDialog.setAnnotation(annotation);
		addSiteDialog.selectSave();

		Wait.forInvisibilityOfElementLocated(this.driver,
				this.getLoadingStatusLocator(), 30);
	}

	/**
	 * Deletes the site. Throws {@link Exception} if it cannot find the site.
	 * 
	 * @param siteName
	 *            the site name.
	 * @throws InterruptedException 
	 */
	public void deleteSite(String siteName) throws InterruptedException {
		Thread.sleep(3000);
		selectSite(siteName);

		// Selects the delete button.
		this.deleteButton.click();

		DeleteSiteDialogbox deleteDialog = new DeleteSiteDialogbox(driver,
				"https://localhost:9402/deploy");
		deleteDialog.get();

		deleteDialog.selectYes();

		// Wait for completion.
		Wait.forInvisibilityOfElementLocated(this.driver,
				deleteDialog.getLoadingStatusLocator(), 30);
	}

	public void refreshSites() {
		this.selectRefresh();

		Wait.forVisibilityLocatedBy(this.driver,
				By.xpath(DMConstants.STATUS_LOADING), 120);
	}

	/**
	 * Selects the site in the Site List.
	 * 
	 * @param site
	 *            the site name.
	 */
	public void selectSite(String site) {
		getSiteElement(site).click();
	}

	/**
	 * Gets the WebElement of a site from the Site List.
	 * 
	 * @param site
	 *            the site name.
	 * @return a WebElement object of a site.
	 * @throws NoSuchElementException
	 *             if no element found for site name.
	 */
	public WebElement getSiteElement(String site) throws NoSuchElementException {
		return driver.findElement(By
				.xpath("//div[2]/div/div/p//span[contains(text(), '" + site
						+ "')]"));
	}

	/**
	 * Gets the count in the Site List. This is the number of sites being added.
	 * 
	 * @return the number of sites being added and shown in the Site List.
	 */
	public int getSiteCount() {
		List<WebElement> tableElems = getSiteListElements();
		return tableElems.size();
	}

	/**
	 * Gets the site list elements. These elements are DIVs which contain the
	 * site name in a P tag and a TABLE which contain the host and port. With
	 * each element on the list, you can find the site name element with the
	 * following: list.get(i).findElement(By.xpath(
	 * ".//p//span[contains(text(), 'site_name')]"); To find the host name,
	 * list.get(i).findElement(By.xpath(
	 * ".//table//tr[1]//td[contains(text(), 'host_name')]"); To find the port,
	 * list.get(i).findElement(By.xpath(
	 * ".//table//tr[2]//td[contains(text(), 'port')]");
	 * 
	 * @return a list of WebElement objects.
	 */
	public List<WebElement> getSiteListElements() {
		List<WebElement> list = new ArrayList<WebElement>();
		WebElement siteListPanel = getSiteListPanelELement();
		try {
			// Gets the DIV element which contains the site name in P tag and
			// TABLE which contain
			// host and port.
			list = siteListPanel.findElements(By.xpath("//table/.."));
		} catch (NoSuchElementException nsee) {
		}

		return list;
	}

	/**
	 * This method navigates to Resource mapping tab
	 */
	public void navigateToResourceMappingsTab() {
		this.getResourceMappingsTabElement().click();
	}

	/**
	 * This method navigates to Resource bundles tab
	 */
	public void navigateToResourceBundlesTab() {
		this.getResourceBundleTabElement().click();
	}
}
