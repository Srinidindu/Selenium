package com.cisco.dm.plans;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DMUtils;
import com.cisco.dm.util.DefaultHeaderPage;
import com.cisco.dm.util.Wait;

/**
 * This class contains methods for user actions on Plans page
 * 
 * @author sdindu
 * 
 */
public class PlanPage extends DefaultHeaderPage {

	public PlanPage(WebDriver webDriver, String url) {
		super(webDriver, url);
	}

	public void addPlan(String planName, String description,
			String sourceSiteName, String targetSiteName) throws Exception {

		// click add plan button
		Thread.sleep(3000);
		Wait.forElementVisibility(
				driver,
				driver.findElement(By.xpath(DMConstants.XPATH_PLAN_ADD_BUTTON)),
				25);
		driver.findElement(By.xpath(DMConstants.XPATH_PLAN_ADD_BUTTON)).click();

		// input all parameters: planName, description, sourceSiteName and
		// targetSiteName
		driver.findElement(By.xpath(DMConstants.XPATH_ADD_PLAN_NAME_FIELD))
				.sendKeys(planName);
		driver.findElement(
				By.xpath(DMConstants.XPATH_ADD_PLAN_DESCRIPTION_FIELD)).clear();

		driver.findElement(
				By.xpath(getSourceSiteSelectOptionXpath(sourceSiteName)))
				.click();
		driver.findElement(
				By.xpath(getTargetSiteSelectOptionXpath(targetSiteName)))
				.click();
		// click OK button
		driver.findElement(By.xpath(DMConstants.XPATH_ADD_PLAN_OK_BUTTON))
				.click();
	}

	public void addMigrateOperation(String planName, String resourceBundleName,
			String targetLocation) throws InterruptedException {
		Wait.forVisibilityLocatedBy(driver, (By.xpath(getPlanXpath(planName))),
				20);
		driver.findElement(By.xpath(getPlanXpath(planName))).click();
		driver.findElement(By.xpath(DMConstants.XPATH_OPERATION_EDIT_BUTTON))
				.click();
		driver.findElement(By.xpath(DMConstants.XPATH_OPERATION_ADD_BUTTON))
				.click();
		driver.findElement(
				By.xpath(DMConstants.XPATH_OEPRATION_TYPE_MIGRATE_MENU_ITEM))
				.click();
		driver.findElement(
				By.xpath(DMConstants.XPATH_MIGRATE_RESOURCE_BUNDLE_RADIO_BUTTON))
				.click();
		driver.findElement(
				By.xpath(DMConstants.XPATH_SELECT_RESOURCE_BUNDLE_OK_BUTTON))
				.click();

		Wait.forElementVisibility(
				driver,
				driver.findElement(By.xpath(DMConstants.XPATH_TARGET_LOCATION)),
				25);

		DMUtils.doubleClick(driver,
				driver.findElement(By.xpath(DMConstants.XPATH_TARGET_LOCATION)));
		DMUtils.doubleClick(driver, driver.findElement(By
				.xpath(".//span[text()='localhost_9410']")));
		selectLocation(targetLocation);
		driver.findElement(By.xpath(DMConstants.XPATH_OPERATION_SAVE_BUTTON))
				.click();
	}

	public void selectLocation(String targetLocation)
			throws InterruptedException {

		Thread.sleep(3000);

		driver.findElement(By.xpath(".//span[text()='shared']")).click();
		driver.findElement(
				By.xpath(DMConstants.XPATH_SELECT_TARGET_LOCATION_OK_BUTTON))
				.click();
	}

	private String getResourceNodeXpath(String resourceName) {
		return new StringBuffer(
				DMConstants.XPATH_SELECT_TARGET_LOCATION_RESOURCE_NODE)
				.replace(
						DMConstants.XPATH_SELECT_TARGET_LOCATION_RESOURCE_NODE
								.indexOf("<"),
						DMConstants.XPATH_SELECT_TARGET_LOCATION_RESOURCE_NODE
								.indexOf(">") + 1, resourceName).toString();
	}

	private String getSourceSiteSelectOptionXpath(String sourceSiteName) {
		return new StringBuffer(DMConstants.XPATH_PLAN_SOURCE_SITE_OPTION)
				.replace(
						DMConstants.XPATH_PLAN_SOURCE_SITE_OPTION.indexOf("<"),
						DMConstants.XPATH_PLAN_SOURCE_SITE_OPTION.indexOf(">") + 1,
						sourceSiteName).toString();
	}

	private String getTargetSiteSelectOptionXpath(String sourceSiteName) {
		return new StringBuffer(DMConstants.XPATH_PLAN_TARGET_SITE_OPTION)
				.replace(
						DMConstants.XPATH_PLAN_TARGET_SITE_OPTION.indexOf("<"),
						DMConstants.XPATH_PLAN_TARGET_SITE_OPTION.indexOf(">") + 1,
						sourceSiteName).toString();
	}
 
	public String getPlanXpath(String planName) {
		return new StringBuffer(DMConstants.XPATH_PLAN).replace(
				DMConstants.XPATH_PLAN.indexOf("<"),
				DMConstants.XPATH_PLAN.indexOf(">") + 1, planName).toString();
	}

	public void executePlan(String planName) {
		driver.findElement(By.xpath(getPlanXpath(planName))).click();
		driver.findElement(By.xpath(DMConstants.XPATH_EXECUTE_BUTTON)).click();
	}
}
