/**
 * 
 */
package com.cisco.dm.util;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cisco.dm.dialogbox.ConfirmLogoutDialogbox;

/**
 * A LoadableModule base class which contain the header interfaces to handle the
 * getting/selecting of the menu items.
 * 
 * @author nochin
 * 
 */
public class DefaultHeaderPage extends DefaultPage {
	@FindBy(css = DMConstants.HEADER_HOME)
	private WebElement homeMenu;
	@FindBy(xpath = DMConstants.HEADER_SITES)
	private WebElement sitesMenu;
	@FindBy(xpath = DMConstants.HEADER_PLANS)
	private WebElement plansMenu;
	@FindBy(xpath = DMConstants.HEADER_ADMIN)
	private WebElement adminMenu;
	@FindBy(xpath = DMConstants.HEADER_HELP)
	private WebElement helpMenu;
	@FindBy(xpath = DMConstants.HEADER_LOGOUT)
	private WebElement logoutMenu;

	public DefaultHeaderPage(WebDriver driver, String url) {
		super(driver, url);
	}

	/**
	 * Gets the home icon. This is the Deployment Manager icon next to the Cisco icon.
	 * 
	 * @return	the WebElement object of the home icon.
	 */
	public WebElement getHomeMenuElement() {
		return this.homeMenu;
	}

	/**
	 * Gets the Sites menu WebElement.
	 * 
	 * @return	the WebElement object.
	 */
	public WebElement getSitesMenuElement() {
		return this.sitesMenu;
	}

	/**
	 * Gets the Plans menu WebElement.
	 * 
	 * @return	the WebElement object.
	 */
	public WebElement getPlansMenuElement() {
		return this.plansMenu;
	}

	/**
	 * Gets the Admin menu WebElement.
	 * 
	 * @return	the WebElement object.
	 */
	public WebElement getAdminMenuElement() {
		return this.adminMenu;
	}

	/**
	 * Gets the Help menu WebElement.
	 * 
	 * @return	the WebElement object.
	 */
	public WebElement getHelpMenuElement() {
		return this.helpMenu;
	}

	/**
	 * Gets the Logout menu WebElement.
	 * 
	 * @return	the WebElement object.
	 */
	public WebElement getLogoutMenuElement() {
		return this.logoutMenu;
	}

	/**
	 * Selects the Home menu. This is the Deployment Manager icon which takes you to the home
	 * page.
	 */
	public void selectHome() {
		this.homeMenu.click();
	}

	/**
	 * Selects the Sites menu.
	 */
	public void selectSites() {
		Wait.forElementVisibility(driver, sitesMenu, 25);
		this.sitesMenu.click();
	}

	/**
	 * Selects the Plans menu.
	 */
	public void selectPlans() {
		this.plansMenu.click();
	}
	
	/**
	 * Selects the drop down menu on the Admin menu. The parameter "menuitem" is a string
	 * of an item in the drop down menu. This method waits for the menuitem to appear before
	 * it is clicked.
	 * 
	 * @param menuitem	the drop down menu item.
	 */
	public void selectAdminMenu(String menuitem)
	{
		performMove(this.adminMenu);
		
		// wait until item appear before click.
		new WebDriverWait(driver, 15).until(ExpectedConditions.visibilityOfElementLocated(By.linkText(menuitem))).click();
	}
	
	/**
	 * Selects the logout menu.
	 */
	public void selectLogout() 
	{
		this.logoutMenu.click();
		
		ConfirmLogoutDialogbox confirm = new ConfirmLogoutDialogbox(this.driver, this.BASE_URL);
		confirm.get();
		
		Wait.forElementVisibility(driver, confirm.getTitleElement(), 15);
		
		confirm.selectYes();
		
		// Delay to allow CIS server to logoff before driver unloads.
		DMUtils.dmWait(1000);
	}
}
