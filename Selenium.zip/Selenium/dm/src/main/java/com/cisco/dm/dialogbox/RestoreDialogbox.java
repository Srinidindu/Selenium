package com.cisco.dm.dialogbox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DefaultPage;

/**
 * A class to handle the Restore dialogbox.
 * 
 * @author nochin
 *
 */
public class RestoreDialogbox extends DefaultPage {
	@FindBy(xpath = DMConstants.DIALOGBOX_RESTORE_TITLE)
	private WebElement title;	
	@FindBy(xpath = DMConstants.DIALOGBOX_RESTORE_BROWSE_BUTTON)
	private WebElement browseButton;	
	@FindBy(xpath = DMConstants.DIALOGBOX_RESTORE_OVERWRITE_CHECKBOX)
	private WebElement overwriteCheckbox;	
	@FindBy(xpath = DMConstants.DIALOGBOX_RESTORE_UPLOAD_BUTTON)
	private WebElement uploadButton;	
	@FindBy(xpath = DMConstants.DIALOGBOX_RESTORE_CANCEL_BUTTON)
	private WebElement cancelButton;	

	public RestoreDialogbox(WebDriver driver, String url) {
		super(driver, url);
	}

	/**
	 * Gets the dialogbox title WebElement.
	 * 
	 * @return	a WebElement object.
	 */
	public WebElement getTitleElement() {
		return this.title;
	}

	/**
	 * Gets the Browse button WebElement.
	 * 
	 * @return	a WebElement object.
	 */
	public WebElement getBrowseButtonElement() {
		return this.browseButton;
	}

	/**
	 * Gets the Overwrite checkbox WebElement.
	 * 
	 * @return	a WebElement object.
	 */
	public WebElement getOverwriteCheckboxElement() {
		return this.overwriteCheckbox;
	}

	/**
	 * Gets the Upload button WebElement.
	 * 
	 * @return	a WebElement object.
	 */
	public WebElement getUploadButtonElement() {
		return this.uploadButton;
	}

	/**
	 * Gets the Cancel button WebElement.
	 * 
	 * @return	a WebElement object.
	 */
	public WebElement getCancelButtonElement() {
		return this.cancelButton;
	}

	/**
	 * Selects the Cancel button.
	 */
	public void selectCancel() {
		getCancelButtonElement().click();
	}
	
	/**
	 * Selects the Upload button.
	 */
	public void selectUpload() {
		getUploadButtonElement().click();
	}
	
	/**
	 * Selects the Browse button.
	 */
	public void selectBrowse() {
		getBrowseButtonElement().click();
	}
}
