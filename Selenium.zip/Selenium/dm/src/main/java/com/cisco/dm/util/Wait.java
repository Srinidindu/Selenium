package com.cisco.dm.util;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * A generic wait class to wait on certain condition of an element for a specified time.
 * 
 * @author nochin
 *
 */
public class Wait {

	/**
	 * Wait for an element visibility for a specified maximum wait timeout.
	 * 
	 * @param driver	the WebDriver.
	 * @param element	the WebElement object.
	 * @param timeout	the maximum wait time in seconds.
	 */
	public static void forElementVisibility(WebDriver driver, WebElement element, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	/**
	 * Wait for an element visibility by the specified locator object for a specified 
	 * maximum wait timeout.
	 * 
	 * @param driver	the WebDriver.
	 * @param by		the (By) locator object.
	 * @param timeout	the maximum wait time in seconds.
	 */
	public static void forVisibilityLocatedBy(WebDriver driver, By by, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(by));
	}

	/**
	 * Wait for elements visibility for a specified maximum wait timeout.
	 * 
	 * @param driver	the WebDriver.
	 * @param elements	the WebElement objects in a list.
	 * @param timeout	the maximum wait time in seconds.
	 */
	public static void forElementsVisibility(WebDriver driver, List <WebElement> elements, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.visibilityOfAllElements(elements));
	}

	/**
	 * Wait for an element to be clickable for a specified maximum wait timeout.
	 * 
	 * @param driver	the WebDriver.
	 * @param element	the WebElement object.
	 * @param timeout	the maximum wait time in seconds.
	 */
	public static void forElementToBeClickable(WebDriver driver, WebElement element, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	/**
	 * Wait for an element to be to be selected for a specified maximum wait timeout.
	 * 
	 * @param driver	the WebDriver.
	 * @param element	the WebElement object.
	 * @param timeout	the maximum wait time in seconds.
	 */
	public static void forElementToBeSelected(WebDriver driver, WebElement element, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.elementToBeSelected(element));
	}

	/**
	 * Wait for a text of an element to be present for a specified maximum wait timeout.
	 * 
	 * @param driver	the WebDriver.
	 * @param element	the WebElement object.
	 * @param text		the text to wait on.
	 * @param timeout	the maximum wait time in seconds.
	 */
	public static void forElementTextToBePresent(WebDriver driver, WebElement element, String text, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.textToBePresentInElement(element, text));
	}
	
	/**
	 * Wait for an element's attribute to change for a specified maximum wait timeout.
	 * 
	 * @param driver	the WebDriver.
	 * @param element	the WebElement object.
	 * @param attribute	the attribute of an element.
	 * @param value		the value that is going to changed to.
	 * @param timeout	the maximum wait time in seconds.
	 */
	public static void forElementAttributeChanged(WebDriver driver, WebElement element, String attribute, String value, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, timeout);
        final String status = element.getAttribute(attribute);
        final String initialValue = value;
		wait.until(new ExpectedCondition <Boolean>() {
            public Boolean apply(WebDriver driver) {
				return status.equals(initialValue );
            }
		});
	}

	/**
	 * Wait for the invisibility of an element specified by the locator (By) object for a
	 * specified maximum wait timeout.
	 * 
	 * @param driver	the WebDriver.
	 * @param locator	the By locator object.
	 * @param timeout	the maximum wait time in seconds.
	 */
	public static void forInvisibilityOfElementLocated(WebDriver driver, By locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, timeout);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
	}
}
