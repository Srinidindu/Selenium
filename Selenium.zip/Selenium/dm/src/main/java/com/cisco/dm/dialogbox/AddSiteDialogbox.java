package com.cisco.dm.dialogbox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DefaultPage;
import com.cisco.dm.util.Wait;

/**
 * An Add Site dialogbox class.
 * 
 * @author nochin
 */
public class AddSiteDialogbox extends DefaultPage
{
	@FindBy(css = DMConstants.DIALOGBOX_ADD_SITE_HOST)
	private WebElement host;	
	@FindBy(css = DMConstants.DIALOGBOX_ADD_SITE_PORT)
	private WebElement port;	
	@FindBy(css = DMConstants.DIALOGBOX_ADD_SITE_NAME)
	private WebElement name;	
	@FindBy(css = DMConstants.DIALOGBOX_ADD_SITE_DOMAIN)
	private WebElement domain;	
	@FindBy(css = DMConstants.DIALOGBOX_ADD_SITE_USER)
	private WebElement user;	
	@FindBy(css = DMConstants.DIALOGBOX_ADD_SITE_PASSWORD)
	private WebElement password;	
	@FindBy(css = DMConstants.DIALOGBOX_ADD_SITE_ANNOTATION)
	private WebElement annotation;	
	@FindBy(xpath = DMConstants.DIALOGBOX_ADD_SITE_SAVE)
	private WebElement saveButton;	
	@FindBy(xpath = DMConstants.DIALOGBOX_ADD_SITE_CANCEL)
	private WebElement cancelButton;	

	public AddSiteDialogbox(WebDriver driver, String url) 
	{
		super(driver, url);
	}
	
	public WebElement getHostElement()
	{
		return this.host;
	}
	
	public void setHost(String host)
	{
		sendKeys(getHostElement(), host, true);
	}
	
	public WebElement getPortElement()
	{
		return this.port;
	}
	
	public void setPort(String port)
	{
		sendKeys(getPortElement(), port, true);
	}
	
	public WebElement getNameElement()
	{
		return this.name;
	}
	
	public void setName(String name)
	{
		sendKeys(getNameElement(), name, true);
	}
	
	public WebElement getDomainElement()
	{
		return this.domain;
	}
	
	public void setDomain(String domain)
	{
		sendKeys(getDomainElement(), domain, true);
	}
	
	public WebElement getUserElement()
	{
		return this.user;
	}
	
	public void setUser(String user)
	{
		sendKeys(getUserElement(), user, true);
	}
	
	public WebElement getPasswordElement()
	{
		return this.password;
	}
	
	public void setPassword(String password)
	{
		sendKeys(getPasswordElement(), password, true);
	}
	
	public WebElement getAnnotationElement()
	{
		return this.annotation;
	}
	
	public void setAnnotation(String annotation)
	{
		sendKeys(getAnnotationElement(), annotation, true);
	}
	
	public WebElement getSaveButtonElement()
	{
		return this.saveButton;
	}
		
	public void selectSave()
	{
		WebElement saveB = getSaveButtonElement();
		
		Wait.forElementToBeClickable(driver, saveB, 30);
		saveB.click();
	}
		
	public WebElement getCancelButtonElement()
	{
		return this.cancelButton;
	}
	
	public void selectCancel()
	{
		getCancelButtonElement().click();
	}
}
