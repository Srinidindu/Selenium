package com.cisco.dm;

import static com.cisco.dm.util.DMConstants.LOGIN_PAGE_DOMAIN;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DefaultPage;
import com.cisco.dm.util.Wait;

/**
 * Login page object class
 * 
 * @author nochin
 * 
 */
public class LoginPage extends DefaultPage {
	@FindBy(css = DMConstants.LOGIN_PAGE_DOMAIN)
	private WebElement domain;	
	@FindBy(css = DMConstants.LOGIN_PAGE_USERNAME)
	private WebElement username;	
	@FindBy(css = DMConstants.LOGIN_PAGE_PASSWORD)
	private WebElement password;	
	@FindBy(xpath = DMConstants.LOGIN_PAGE_BUTTON)
	private WebElement loginButton;	

	public LoginPage(WebDriver webDriver, String url) {
		super(webDriver, url);		
	}

	/**
	 * A method to login to Deployment Manager.
	 * 
	 * @param domain 	The domain name.
	 * @param username	The user name.
	 * @param password	The password.
	 */
	public void login(String domain, String username, String password) {
		// enter fields: username, password
		sendKeys(this.domain, domain, true);
		sendKeys(this.username, username, true);
		sendKeys(this.password, password, true);

		// click login button
		this.loginButton.click();
	}

	@Override
	protected void isLoaded() throws Error 
	{
		super.isLoaded();
		
		// Since home page and login page url are the same, we need to have a way to
		// differentiate the two. We need to check if certain element on the page is visible
		// and if not, then we know we are not at the page as expected. Do a page load when
		// not on expected page.
		try {
			this.driver.findElement(By.cssSelector(LOGIN_PAGE_DOMAIN));
		} catch (NoSuchElementException nsee) {
			// Not at login page... Call load to force load.
			super.load();
			Wait.forVisibilityLocatedBy(driver, By.cssSelector(LOGIN_PAGE_DOMAIN), 30);
		}
	}

	public WebElement getDomainElement() {
		return this.domain;
	}

	public void setDomain(String domain) {
		sendKeys(getDomainElement(), domain, true);
	}

	public WebElement getUsernameElement() {
		return this.username;
	}

	public void setUsername(String username) {
		sendKeys(getUsernameElement(), username, true);
	}

	public WebElement getPasswordElement() {
		return this.password;
	}

	public void setPassword(String password) {
		sendKeys(getPasswordElement(), password, true);
	}

	public WebElement getLoginButtonElement() {
		return this.loginButton;
	}

}
