package com.cisco.dm.util;

/**
 * This class contains the constants used by deployment manager frameworks and
 * tests
 * 
 * @author sdindu
 * 
 * 
 */
public class DMConstants {
	// ------------------------ SYSTEM PROPERTIES ------------------------
	public static final String CHROME_DRIVER_PATH = "src/test/resources/chromedriver.exe";

	// ------------------------LOCATORS------------------------
	// Header locators
	public static final String HEADER_HOME 		= "a[title='Go Home']";
	public static final String HEADER_SITES 	= "//nav/ul/li/a[contains(text(), 'Sites')]";
	public static final String HEADER_PLANS 	= "//nav/ul/li/a[contains(text(), 'Plans')]";
	public static final String HEADER_ADMIN 	= "//nav/ul/li/a[contains(text(), 'Admin')]";
	public static final String HEADER_HELP 		= "//nav/ul/li/a[contains(text(), 'Help')]";
	public static final String HEADER_LOGOUT 	= "//nav/ul/li/a[contains(text(), 'Logout')]";

	// Footer locators
	public static final String FOOTER_PRODUCT_TITLE = "//div[2]/div/div[3]//div[contains(text(), 'Deployment Manager')]";
	public static final String FOOTER_COPYRIGHT 	= "//div[contains(text(),'Copyright')]";
	
	// Popup status message text
	public static final String STATUS_TEXT_REFRESHING_SITES = "Refreshing sites...";

	// Status locators
	public static final String STATUS_LOADING = "//div[3]/div[contains(text(), 'Loading...')]/..";
	public static final String STATUS_REFRESHING_SITES = "//div/div/div/div[contains(text(), '"+STATUS_TEXT_REFRESHING_SITES+"')]";
	
	// home page locators
	public static final String HOME_PAGE_TITLE = "//article/../div//span";
	public static final String HOME_PAGE_BUTTON_MANAGE_SITES = "//button/div[contains(text(), 'Manage Sites')]";
	public static final String HOME_PAGE_BUTTON_MANAGE_PLANS = "//button/div[contains(text(), 'Manage Plans')]";
	public static final String HOME_PAGE_MANAGE_SITES_COUNT_DESCRIPTION = HOME_PAGE_BUTTON_MANAGE_SITES+"/../../../../div[1]/div";
	public static final String HOME_PAGE_MANAGE_SITES_COUNT = HOME_PAGE_MANAGE_SITES_COUNT_DESCRIPTION+"//span";
	public static final String HOME_PAGE_MANAGE_SITES_DESCRIPTION = HOME_PAGE_BUTTON_MANAGE_SITES+"/../../../../div[3]";
	public static final String HOME_PAGE_MANAGE_PLANS_COUNT_DESCRIPTION = HOME_PAGE_BUTTON_MANAGE_PLANS+"/../../../../div[1]/div";
	public static final String HOME_PAGE_MANAGE_PLANS_COUNT = HOME_PAGE_MANAGE_PLANS_COUNT_DESCRIPTION+"//span";
	public static final String HOME_PAGE_MANAGE_PLANS_DESCRIPTION = HOME_PAGE_BUTTON_MANAGE_PLANS+"/../../../../div[3]";

	// login page locators
	public static final String LINK_LOGOUT = "Logout";
	public static final String LOGIN_PAGE_DOMAIN 	= "input[placeholder='(domain)']";
	public static final String LOGIN_PAGE_USERNAME 	= "input[placeholder='(username)']";
	public static final String LOGIN_PAGE_PASSWORD 	= "input[placeholder='(password)']";
	public static final String LOGIN_PAGE_BUTTON 	= ".//button[contains(text(),'Login')]";
	public static final String LOGIN_PAGE_MESSAGE 	= "table ~ div";
	
	public static final String LOGIN_PAGE_STATUS_AUTHENTICATION_FAILED = "//div[contains(text(), 'Authentication Failed')]/../div[contains(text(),'Please re-enter your login credentials')]";

	// sites page locators
	public static final String SITE_PAGE_SITE_LIST 		= "//article/../div//span[contains(.,'Site List')]";
	public static final String SITE_PAGE_SITE_LIST_PANEL = SITE_PAGE_SITE_LIST+"/../../../../div[2]/div/div/div[2]/div";
	public static final String SITE_PAGE_ADD_BUTTON 	= "//div[2]/div[2]//div[contains(text(),'Add')]";
	public static final String SITE_PAGE_DELETE_BUTTON 	= "//div[2]/div[2]//div[contains(text(),'Delete')]";
	public static final String SITE_PAGE_REFRESH_BUTTON = "//div[2]/div[2]//div[contains(text(),'Refresh')]";
	public static final String SITE_PAGE_SITE_DETAILS_TAB_CONTROLS = "//article/../div//ul";
	public static final String SITE_PAGE_SITE_DETAILS_TAB_RESOURCE_BUNDLES = SITE_PAGE_SITE_DETAILS_TAB_CONTROLS+"/li//span[contains(text(),'Resource Bundles')]";
	public static final String SITE_PAGE_SITE_DETAILS_TAB_PRINCIPAL_BUNDLES = SITE_PAGE_SITE_DETAILS_TAB_CONTROLS+"/li//span[contains(text(),'Principal Bundles')]";
	public static final String SITE_PAGE_SITE_DETAILS_TAB_RESOURCE_MAPPINGS = SITE_PAGE_SITE_DETAILS_TAB_CONTROLS+"/li//span[contains(text(),'Resource Mappings')]";
	public static final String SITE_PAGE_SITE_DETAILS_TAB_PRINCIPAL_MAPPINGS = SITE_PAGE_SITE_DETAILS_TAB_CONTROLS+"/li//span[contains(text(),'Principal Mappings')]";
	public static final String SITE_PAGE_SITE_DETAILS_TAB_GENERAL = SITE_PAGE_SITE_DETAILS_TAB_CONTROLS+"/li//span[contains(text(),'General')]";

	public static final String XPATH_RESOURCE_BUNDLE_NODE = ".//span[(text()= 'TEST_RESOURCE_BUNDLE')]";
	public static final String XPATH_RESOURCE_NODE_IMG = ".//span[contains(text(),'<RESOURCE_NAME_PLACE_HOLDER>')]/../img[2]";
	public static final String XPATH_RESOURCE_NODE = ".//span[contains(text(),'RESOURCE_NAME_PLACE_HOLDER')]";
	public static final String XPATH_ADD_RESOURCE_BUNDLE_BUTTON = ".//div[contains(text(),'Add Resource Bundle')]";
	public static final String XPATH_TAB_RESOURCE_MAPPINGS = ".//span[contains(text(),'Resource Mappings')]";
	public static final String XPATH_TAB_RESOURCE_BUNDLES = ".//span[contains(text(),'Resource Bundles')]";

	// resource bundle locators
	//public static final String XPATH_NAME_FIELD = "(.//div[@class='GENO2BVBDRB']//input)[26]";
	//public static final String XPATH_NAME_FIELD = "(.//div[@class='GFNF2R4DPRB']//input)[26]";
	public static final String XPATH_NAME_FIELD = ".//input[@id='gwt-debug-NewRBundle-name-input']";
	public static final String RESOURCE_BUNDLE_COPY_BUTTON = "id('gwt-debug-resource-bundles-toolbar')/x:div/x:div[2]/x:div/x:div";	

	//public static final String XPATH_ANNOTATION_FIELD = "(.//div[@class='GENO2BVBKQB']//textarea)[4]";
	//public static final String XPATH_ANNOTATION_FIELD = "(.//div[@class='GFNF2R4DGRB']//textarea)[4]";
	public static final String XPATH_ANNOTATION_FIELD = ".//textarea[@id='x-auto-39-input']";
	
	//public static final String XPATH_ADD_BUNDLE_BUTTON = ".//div[@class='GENO2BVBFJB']//div[contains(text(),'Add Bundle')]";
	//public static final String XPATH_ADD_BUNDLE_BUTTON = ".//div[@class='GFNF2R4DBKB']//div[contains(text(),'Add Bundle')]";
	public static final String XPATH_ADD_BUNDLE_BUTTON = ".//div[starts-with(@class,'G')]//div[contains(text(),'Add Bundle')]";

	// resource mapping locators
	public static final String XPATH_EDIT_MAPPING_BUTTON = ".//div[contains(text(),'<DATASOURCE_PLACEHOLDER>')]/../../td[3]/div";
	public static final String XPATH_ADD_TARGET_SITE_BUTTON = ".//div[@id='gwt-debug-Mappings-addTargetButton']";
	public static final String XPATH_TARGET_SITE_SELECT = ".//td/div[contains(text(),'<TARGET_SITE_PLACEHOLDER>')]";
	public static final String XPATH_TARGET_SITE_OK_BUTTON = ".//div[contains(text(), 'OK')]";
	public static final String XPATH_POPULATE_BUTTON = ".//div[contains(text(),'Populate')]";
	public static final String XPATH_EDIT_MAPPING_OK_BUTTON = ".//div[contains(text(), 'OK')]";

	// plan page locators
	public static final String XPATH_PLAN = ".//p//span[contains(text(),'<PLAN_PLACEHOLDER>')]";
	public static final String XPATH_PLAN_ADD_BUTTON = "(//div[contains(text(),'Add')])[2]";
	public static final String XPATH_ADD_PLAN_NAME_FIELD = ".//input[@placeholder='Enter your Deployment Plan Name...']";
	public static final String XPATH_ADD_PLAN_DESCRIPTION_FIELD = ".//textarea[@placeholder='Enter your Annotation...']";
	public static final String XPATH_PLAN_SOURCE_SITE_OPTION = "(//select/option[@value='<SITE_NAME_PLACE_HOLDER>'])[1]";
	public static final String XPATH_PLAN_TARGET_SITE_OPTION = "(//select/option[@value='<SITE_NAME_PLACE_HOLDER>'])[2]";
	public static final String XPATH_ADD_PLAN_OK_BUTTON = ".//div[contains(text(), 'OK')]";
	public static final String XPATH_OPERATION_EDIT_BUTTON = "(.//div[contains(text(),'Edit')])[1]";
	public static final String XPATH_OPERATION_ADD_BUTTON = "(.//div[contains(text(),'Add')])[1]";
	public static final String XPATH_OEPRATION_TYPE_MIGRATE_MENU_ITEM = ".//span[contains(text(),'Type Migrate...')]";
	public static final String XPATH_MIGRATE_RESOURCE_BUNDLE_RADIO_BUTTON = ".//input[@type='radio']";
	public static final String XPATH_SELECT_RESOURCE_BUNDLE_OK_BUTTON = ".//div[contains(text(), 'OK')]";
	public static final String XPATH_TARGET_LOCATION = ".//div[contains(text(),'Target Location')]";
	public static final String XPATH_SELECT_TARGET_LOCATION_OK_BUTTON = ".//div[contains(text(), 'OK')]";
	public static final String XPATH_SELECT_TARGET_LOCATION_RESOURCE_IMG = ".//div//span[contains(text(),'<PLACE_HOLDER>')]/../img[2]";
	public static final String XPATH_SELECT_TARGET_LOCATION_RESOURCE = ".//div//span[contains(text(),'<PLACE_HOLDER>')]";
	public static final String XPATH_OPERATION_SAVE_BUTTON = "(.//div[contains(text(),'Save')])[1]";
	public static final String XPATH_EXECUTE_BUTTON = ".//div[contains(text(),'Execute')]";

	// Dialog box
	public static final String DIALOGBOX_CONFIRM_TITLE 		= "//div[contains(text(), 'Confirm Logout')]";
	public static final String DIALOGBOX_CONFIRM_MESSAGE 	= "//div[contains(text(), 'Confirm Logout')]/../../../div[2]//div[2]";
	public static final String DIALOGBOX_CONFIRM_YES_BUTTON = "//div[contains(text(), 'Confirm Logout')]/../../..//div[contains(text(), 'Yes')]";
	public static final String DIALOGBOX_CONFIRM_NO_BUTTON 	= "//div[contains(text(), 'Confirm Logout')]/../../..//div[contains(text(), 'No')]";
	
	// Add site dialogbox
	public static final String DIALOGBOX_ADD_SITE_HOST 		= "input[placeholder='Enter Host']";
	public static final String DIALOGBOX_ADD_SITE_PORT 		= "input[placeholder='Enter Port']";
	public static final String DIALOGBOX_ADD_SITE_NAME 		= "input[placeholder='Enter Name']";
	public static final String DIALOGBOX_ADD_SITE_DOMAIN 	= "input[placeholder='Enter Domain']";
	public static final String DIALOGBOX_ADD_SITE_USER 		= "input[placeholder='Enter User']";
	public static final String DIALOGBOX_ADD_SITE_PASSWORD 	= "input[placeholder='Enter Password']";
	public static final String DIALOGBOX_ADD_SITE_ANNOTATION 	= "textarea[placeholder='Enter Annotation']";
	public static final String DIALOGBOX_ADD_SITE_SAVE 		= "//div[contains(text(), 'Add Site')]/../../../div[2]//div[contains(text(),'Save')]";
	public static final String DIALOGBOX_ADD_SITE_CANCEL 	= "//div[contains(text(), 'Add Site')]/../../../div[2]//div[contains(text(),'Cancel')]";

	// Delete site dialogbox
	public static final String DIALOGBOX_DELETE_SITE_MESSAGE 	= "//div[contains(text(),'Delete Site')]/../../../div[2]/div/div[2]";
	public static final String DIALOGBOX_DELETE_SITE_YES_BUTTON = "//div[contains(text(),'Delete Site')]/../../../div[2]//div[contains(text(), 'Yes')]";
	public static final String DIALOGBOX_DELETE_SITE_NO_BUTTON 	= "//div[contains(text(),'Delete Site')]/../../../div[2]//div[contains(text(), 'No')]";

	// Backup dialogbox
	public static final String DIALOGBOX_BACKUP_TITLE 			= "//div[contains(text(), 'Download backup file')]";
	public static final String DIALOGBOX_BACKUP_MESSAGE 		= "//div[contains(text(), 'Download backup file')]/../../../div[2]//div[2]";
	public static final String DIALOGBOX_BACKUP_DOWNLOAD_BUTTON = "//div[contains(text(), 'Download backup file')]/../../..//div[contains(text(), 'Download')]";
	public static final String DIALOGBOX_BACKUP_CANCEL_BUTTON 	= "//div[contains(text(), 'Download backup file')]/../../..//div[contains(text(), 'Cancel')]";
	
	// Restore dialogbox
	public static final String DIALOGBOX_RESTORE_TITLE 			= "//div[contains(text(), 'Upload .car file to import')]";
	public static final String DIALOGBOX_RESTORE_BROWSE_BUTTON = "//div[contains(text(), 'Upload .car file to import')]/../../../div[2]//form//input[@class='gwt-FileUpload']";
	public static final String DIALOGBOX_RESTORE_OVERWRITE_CHECKBOX = "//div[contains(text(), 'Upload .car file to import')]/../../../div[2]//form//input[@type='checkbox']";
	public static final String DIALOGBOX_RESTORE_UPLOAD_BUTTON = "//div[contains(text(), 'Upload .car file to import')]/../../../div[2]//div[contains(text(),'Upload')]";
	public static final String DIALOGBOX_RESTORE_CANCEL_BUTTON 	= "//div[contains(text(), 'Upload .car file to import')]/../../../div[2]//div[contains(text(),'Cancel')]";
	
	// ------------------------TEST DATA------------------------
	// login page test data
	public static final String DOMAINNAME = "composite";
	public static final String USERNAME = "admin";
	public static final String PASSWORD = "admin";
	public static final String PASSWORD_INVALID = "asdfsadf";

	// site page test data
	public static final String HOSTVALUE_LOCALHOST = "localhost";
	public static final Integer PORT_VALUE_9400 = 9400;
	public static final String ANNOTATION_VALUE = "This is a test annotation";

	// resource bundle test data
	public static final String RESOURCE_BUNDLE_NAME = "TEST_RESOURCE_BUNDLE";
	public static final String RESOURCE_BUNDLE_ANNOTATION = "This is a test resource bundle annotation";
	public static final String RESOURCE_PATH = "/localhost_9400/shared";
	public static final String DM_SITE_URL = "https://localhost:9402/deploy/";

	// plan page test data
	public static final String SOURCE_HOSTVALUE_LOCALHOST = "localhost";
	public static final Integer SOURCE_PORT_VALUE = 9400;
	public static final String SOURCE_ANNOTATION_VALUE = "This is a test annotation";
	public static final String TARGET_HOSTVALUE_LOCALHOST = "localhost";
	public static final Integer TARGET_PORT_VALUE = 9410;
	public static final String TARGET_ANNOTATION_VALUE = "This is a test annotation";
	public static final String MIGRATE_SOURCE_RESOURCE_PATH = "/localhost_9400/shared/Source_RS";
	public static final String MIGRATE_TARGET_RESOURCE_PATH = "/localhost_9410/shared";
	public static final String MIGRATE_PLAN_NAME = "TEST_MIGRATE_PLAN";
	public static final String MIGRATE_PLAN_DESCRIPTION = "This is test plan description";
	public static final String XPATH_VALIDATE_RESOURCE_NODE = ".//span[contains(text(),'<RESOURCE_BUNDLE_PLACE)_HOLDER>')]";
	public static final String XPATH_VALIDATE_RESOURCE_NODE_IMG = ".//span[contains(text(),'<RESOURCE_BUNDLE_PLACE)_HOLDER>')]/../img[2]";
	public static final String XPATH_PLAN_EXECUTION_SUCCESS = ".//td[starts-with(text(),'Operation Execution Status: SUCCEEDED')]";
	// resource mapping test data
	public static final String DATASOURCE_ORACLE = "Oracle";
	public static final String RESOURCEMAPPING_ORACLE=".//div[starts-with(text(),'/shared/Source_RS/Oracle')]";
	public static final String MIGRATE_RESOURCEBUNDLE_SOURCE_RESOURCE_PATH = "/localhost_9400/shared/Source_RS";
	public static final String MIGRATE_RESOURCEBUNDLE_TARGET_RESOURCE_PATH = "/localhost_9410/shared";

	// ------------------------ ASSERT MESSAGES ------------------------
	// assert messages
	public static final String ASSERT_TEXT_LINK_USER_LOGOUT_MSG = "LOGOUT link not found";
	public static final String ASSERT_TEXT_INVALID_CREDENTIAL = "Please re-enter your login credentials";
	public static final String ASSERT_TEXT_INVALID_CREDENTIAL_MSG = "Invalid credentials";

	// ------------------------ PRINT MESSAGES ------------------------
	// print messages
	public static final String SYSOUT_MSG_CLICKING_THE_LINK_SITES = "Clicking the Link:'Sites'";
	public static final String SYSOUT_MSG_CLICKING_THE_LINK_PLAN = "Clicking the Link:'Plan'";
	public static final String SYSOUT_MSG_CLICKING_THE_LINK_ADMIN = "Clicking the Link:'Admin'";
	public static final String SYSOUT_MSG_CLICKING_THE_MANAGE_PLANS = "Clicking 'Manage Plans'";
	public static final String SYSOUT_MSG_CLICKING_THE_MANAGE_SITES = "Clicking 'Manage Sites'";
	public static final String SYSOUT_MSG_LOGIN_FAILED = "Login failed!!";
	public static final String SYSOUT_MSG_LOGGING_OUT = "Logging-out!";
	public static final String SYSOUT_MSG_LOGGED_IN_SUCCESSFULLY = "Logged-in successfully!";
	public static final String SYSOUT_MSG_LOGGED_OUT_SUCCESSFULLY = "Logged-out successfully!";
	public static final String SYSOUT_MSG_PLEASE_REENTER_CREDENTIALS_NOT_DISPLAYED = "ERROR MESSAGE\t:\"Please re-enter your login credentials\" is not displayed";
	public static final String SYSOUT_MSG_LOGGING_TO_DM_USING_CREDENTIALS = "Logging in to th deplyment manager using the following credentials:";
	public static final String SYSOUT_DOMAIN_USERNAME_PASSWORD = "DOMAIN\t\t:%s\nUSERNAME\t:%s\nPASSWORD\t:%s\n";
	public static final String XPATH_SELECT_TARGET_LOCATION_RESOURCE_NODE = null;
	public static final String XPATH_SITE_ADD_RESOURCE_TO_RESOURC_BUNDLE_BUTTON = ".//div[@title='Source_RS']";

	// Header Menu and menu items
	public static final String HEADER_MENU_TEXT_SITES 		= "Sites";
	public static final String HEADER_MENU_TEXT_PLANS 		= "Plans";
	public static final String HEADER_MENU_TEXT_ADMIN 		= "Admin";
	public static final String HEADER_MENU_TEXT_HELP 		= "Help";
	public static final String HEADER_MENU_TEXT_LOGOUT 		= "Logout";
	public static final String HEADER_MENU_ITEM_TEXT_BACKUP = "Backup";
	public static final String HEADER_MENU_ITEM_TEXT_RESTORE = "Restore";
	
	// Dialogbox title
	public static final String DIALOGBOX_BACKUP_TEXT_TITLE 	= "Download backup file";
	public static final String DIALOGBOX_RESTORE_TEXT_TITLE = "Upload .car file to import";

}
