package com.cisco.dm;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DefaultHeaderPage;
import com.cisco.dm.util.Wait;

/**
 * The home page class object.
 * 
 * @author nochin
 * 
 */
public class HomePage extends DefaultHeaderPage {
	@FindBy(xpath = DMConstants.HOME_PAGE_TITLE)
	private WebElement title;
	@FindBy(xpath = DMConstants.HOME_PAGE_BUTTON_MANAGE_SITES)
	private WebElement manageSites;
	@FindBy(xpath = DMConstants.HOME_PAGE_BUTTON_MANAGE_PLANS)
	private WebElement managePlans;
	@FindBy(xpath = DMConstants.HOME_PAGE_MANAGE_SITES_COUNT_DESCRIPTION)
	private WebElement sitesCountDescription;
	@FindBy(xpath = DMConstants.HOME_PAGE_MANAGE_SITES_COUNT)
	private WebElement sitesCount;
	@FindBy(xpath = DMConstants.HOME_PAGE_MANAGE_SITES_DESCRIPTION)
	private WebElement sitesDescription;
	@FindBy(xpath = DMConstants.HOME_PAGE_MANAGE_PLANS_COUNT_DESCRIPTION)
	private WebElement plansCountDescription;
	@FindBy(xpath = DMConstants.HOME_PAGE_MANAGE_PLANS_COUNT)
	private WebElement plansCount;
	@FindBy(xpath = DMConstants.HOME_PAGE_MANAGE_PLANS_DESCRIPTION)
	private WebElement plansDescription;

	public HomePage(WebDriver webDriver, String url) {
		super(webDriver, url);
	}

	@Override
	protected void isLoaded() throws Error {
		// Hack: Can use url to determine if page loaded since it's the same as
		// the
		// login page.
		Wait.forVisibilityLocatedBy(driver,
				By.xpath(DMConstants.HEADER_LOGOUT), 30);

		String url = driver.getCurrentUrl();
		assertTrue(url.startsWith(BASE_URL), "Expected url to start with "
				+ BASE_URL + " but was " + url);
	}

	/**
	 * Gets the title web element.
	 * 
	 * @return a WebElement object
	 */
	public WebElement getTitleElement() {
		return title;
	}

	public WebElement getSitesCountDescriptionElement() {
		return sitesCountDescription;
	}

	public WebElement getSitesCountElement() {
		return sitesCount;
	}

	public WebElement getPlansCountDescriptionElement() {
		return plansCountDescription;
	}

	public WebElement getPlansCountElement() {
		return plansCount;
	}

	public WebElement getSitesDescriptionElement() {
		return sitesDescription;
	}

	public WebElement getPlansDescriptionElement() {
		return plansDescription;
	}

	/**
	 * Gets the Manage Site web element.
	 * 
	 * @return a WebElement object
	 */
	public WebElement getManageSitesElement() {
		return manageSites;
	}

	/**
	 * Gets the Manage Plans web element.
	 * 
	 * @return a WebElement object
	 */
	public WebElement getManagePlansElement() {
		return managePlans;
	}

	/**
	 * This method is navigate to Sites page
	 * 
	 * @throws InterruptedException
	 */
	public void navigateToSites() throws InterruptedException {
		// click Sites page link
		selectSites();
	}

	public void navigateToSitesTab() {
		driver.findElement(By.xpath(".//a[text()='Sites']")).click();
	}

	/**
	 * This method is navigate to Plans page
	 */
	public void navigateToPlans() {
		// click Plans page link
		selectPlans();
	}

	/**
	 * This method is navigate to Administration page
	 */
	public void navigateToAdmin() {
		// click ResourceSets page link
		this.driver.findElement(By.xpath(DMConstants.HEADER_ADMIN)).click();
	}

	/**
	 * This method logs out of the application
	 * @throws InterruptedException 
	 */
	public void logout() throws InterruptedException {
		selectLogout();
	}

	public void clickManageSites() {
		this.manageSites.click();
	}

	public void clickManagePlans() {
		this.managePlans.click();
	}

}
