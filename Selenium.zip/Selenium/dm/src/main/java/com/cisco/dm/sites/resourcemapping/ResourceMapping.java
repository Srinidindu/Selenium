package com.cisco.dm.sites.resourcemapping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DefaultHeaderPage;

/**
 * This class contains methods for user actions on Site page
 * 
 * @author sdindu
 * 
 */

public class ResourceMapping extends DefaultHeaderPage {

	public ResourceMapping(WebDriver driver, String url) {
		super(driver, url + "#sites");
	}

	public void clickAddTargetSite() throws Exception {
		Thread.sleep(3000);
		driver.findElement(By.xpath(DMConstants.XPATH_ADD_TARGET_SITE_BUTTON))
				.click();
		Thread.sleep(3000);
		driver.findElement(
				By.xpath(".//td/div[contains(text(), 'localhost_9410')]"))
				.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(DMConstants.XPATH_TARGET_SITE_OK_BUTTON))
				.click();
	}

	public void editMapping(String datasourceName) throws Exception {
		driver.findElement(By.xpath(getEditMappingXpath(datasourceName)))
				.click();
		for (WebElement webElement : driver.findElements(By
				.xpath(DMConstants.XPATH_POPULATE_BUTTON)))
			if (webElement.isDisplayed())
				webElement.click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(DMConstants.XPATH_EDIT_MAPPING_OK_BUTTON))
				.click();
	}

	public String getTargetSiteXpath(String targetSiteName) {
		return new StringBuffer(DMConstants.XPATH_TARGET_SITE_SELECT).replace(
				DMConstants.XPATH_TARGET_SITE_SELECT.indexOf("<"),
				DMConstants.XPATH_TARGET_SITE_SELECT.indexOf(">") + 1,
				targetSiteName).toString();
	}

	public String getEditMappingXpath(String datasourceName) {
		return new StringBuffer(DMConstants.XPATH_EDIT_MAPPING_BUTTON).replace(
				DMConstants.XPATH_EDIT_MAPPING_BUTTON.indexOf("<"),
				DMConstants.XPATH_EDIT_MAPPING_BUTTON.indexOf(">") + 1,
				datasourceName).toString();
	}

	public void selectOracleSourceResource() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(By.xpath(".//div[starts-with(text(),'/shared/Source_RS/Oracle')]"))
				.click();
	}
}
