package com.cisco.dm;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DMUtils;
import com.cisco.dm.util.DriverFactory;
import com.cisco.dm.util.Wait;

/**
 * Test login in Deployment Manager.
 * 
 * @author nchin
 * 
 */
public class LoginPageTests {
    private static final Logger logger = LogManager.getLogger("LoginPageTests");

	WebDriver driver = null;
	HomePage homePage;
	String siteUrl;

	@Parameters({"browser", "siteURL"})
	@BeforeClass
	public void init(String browser, String siteURL) throws Exception {
		logger.info("Starting Login Page Tests");
		driver = DriverFactory.initDriver(browser);
		this.siteUrl = siteURL;
	}
	
	@AfterClass
	public void tearDown() throws Exception {
		DMUtils.closeDriver(this.driver);
	}

	@Test(description="Test case DM-6")
	public void refreshPage() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);
		
		LoginPage loginPage = new LoginPage(this.driver, this.siteUrl);
		loginPage.get();
		
		driver.navigate().refresh();
		
		// Need to do this because of refresh page otherwise page would be staled.
		loginPage = new LoginPage(this.driver, this.siteUrl);
		loginPage.get();
		
		// Validate
		assertTrue(loginPage.getFocusedElement().equals(loginPage.getUsernameElement()), 
				"Focus element is not on Username field after a refresh page.");
		
		logger.info(methodName+": Success.");
	}
	
	@Test(description="Test case DM-661")
	public void initialLogin() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);

		LoginPage loginPage = new LoginPage(this.driver, this.siteUrl);
		loginPage.get();
		
		// Validate against footer
		assertTrue(loginPage.getProductTitleElement().getText().contains("Deployment Manager"),
				"Invalid login screen.");
		
		logger.info(methodName+": Success.");
		DMUtils.dmWait(1000);
	}
	
	@Test(description="Test case DM-2, DM-7")
	public void emptyInputFields() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);
		
		LoginPage loginPage = new LoginPage(this.driver, this.siteUrl);
		loginPage.get();
		
		// Validations
		// Making sure fields are emptied or for domain name, it contains "composite".
		assertTrue(loginPage.getDomainElement().getAttribute("value").equals(DMConstants.DOMAINNAME), "Domain name field does not contain the default domain (composite).");
		assertTrue(loginPage.getUsernameElement().getAttribute("value").isEmpty(), "Username field is not emptied when it should.");
		assertTrue(loginPage.getPasswordElement().getAttribute("value").isEmpty(), "Password field is not emptied when it should.");

		loginPage.setDomain(DMConstants.DOMAINNAME);
		assertFalse(loginPage.getLoginButtonElement().isEnabled(), "Not all required input fields are entered.");
		loginPage.setUsername(DMConstants.USERNAME);
		assertFalse(loginPage.getLoginButtonElement().isEnabled(), "Not all required input fields are entered.");
		loginPage.setPassword(DMConstants.PASSWORD);
		assertTrue(loginPage.getLoginButtonElement().isEnabled(), "All required input fields are entered but the Login button is not enabled.");

		DMUtils.dmWait(1000);	// Delay to allow visual
		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-5, DM-452")
	public void tabAndEnterKey() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);
		
		LoginPage loginPage = new LoginPage(this.driver, this.siteUrl);
		loginPage.get();
		
		// Enter key tests.
		loginPage.setDomain(DMConstants.DOMAINNAME);
		loginPage.getDomainElement().sendKeys(Keys.ENTER);
		
		DMUtils.dmWait(1000);	// Delay to show cursor movement to next field.
		
		// The active element has the focus.
		WebElement focusElem = loginPage.getFocusedElement();	
		//logger.info("Focus element position: "+focusElem.getLocation());
		
		assertTrue(loginPage.getUsernameElement().equals(focusElem), "Focus is not on the username field.");
		
		loginPage.setUsername(DMConstants.USERNAME);
		loginPage.getUsernameElement().sendKeys(Keys.ENTER);
		
		DMUtils.dmWait(1000);	// Delay to show cursor movement to next field.

		focusElem = loginPage.getFocusedElement();	
		assertTrue(loginPage.getPasswordElement().equals(focusElem), "Focus is not on the password field.");

		DMUtils.dmWait(1000);	// Delay to show cursor movement to next field.

		// Tab key tests.
		loginPage.setDomain(DMConstants.DOMAINNAME);
		loginPage.getDomainElement().sendKeys(Keys.TAB);
		
		DMUtils.dmWait(1000);	// Delay to show cursor movement to next field.
		
		focusElem = loginPage.getFocusedElement();	
		assertTrue(loginPage.getUsernameElement().equals(focusElem), "Focus is not on the username field.");
		
		loginPage.setUsername(DMConstants.USERNAME);
		loginPage.getUsernameElement().sendKeys(Keys.TAB);
		
		DMUtils.dmWait(1000);	// Delay to show cursor movement to next field.
		
		focusElem = loginPage.getFocusedElement();	
		assertTrue(loginPage.getPasswordElement().equals(focusElem), "Focus is not on the password field.");

		DMUtils.dmWait(1000);	// Delay to show cursor movement to next field.
		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-667, DM-453, DM-8")
	public void validateLoginFields() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);
		
		LoginPage loginPage = new LoginPage(this.driver, this.siteUrl);
		loginPage.get();
		
		loginPage.setDomain(DMConstants.DOMAINNAME);
		loginPage.setUsername(DMConstants.USERNAME);
		loginPage.setPassword(DMConstants.PASSWORD);
		
		// Validation		
		// DM-453
		assertTrue(loginPage.getPasswordElement().getAttribute("type").equals("password"), "Password field is not a password input type.");
		
		// DM-667, DM-8
		assertTrue(loginPage.getDomainElement().getAttribute("value").contains(DMConstants.DOMAINNAME),
				"Invalid Domain name input. Input contains ["+loginPage.getDomainElement().getAttribute("value")+"] and we are expecting ["+DMConstants.DOMAINNAME+"].");
		assertTrue(loginPage.getUsernameElement().getAttribute("value").contains(DMConstants.USERNAME),
				"Invalid User name input. Input contains ["+loginPage.getUsernameElement().getAttribute("value")+"] and we are expecting ["+DMConstants.USERNAME+"].");
		assertTrue(loginPage.getPasswordElement().getAttribute("value").contains(DMConstants.PASSWORD),
				"Invalid Password input. Input contains ["+loginPage.getPasswordElement().getAttribute("value")+"] and we are expecting ["+DMConstants.PASSWORD+"].");

		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-668, DM-458")
	public void invalidCredentials() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);
		
		LoginPage loginPage = new LoginPage(this.driver, this.siteUrl);
		loginPage.get();
		
		// Login with bad password
		logger.info("Test invalid login with bad password.");
		loginPage.login(DMConstants.DOMAINNAME, DMConstants.USERNAME, DMConstants.PASSWORD_INVALID);
		
		WebElement msgElem = driver.findElement(By.cssSelector(DMConstants.LOGIN_PAGE_MESSAGE));
		Wait.forElementVisibility(driver, msgElem, 15);
		
		assertTrue(msgElem.getText().contains(
				DMConstants.ASSERT_TEXT_INVALID_CREDENTIAL),
				DMConstants.SYSOUT_MSG_PLEASE_REENTER_CREDENTIALS_NOT_DISPLAYED);

		Wait.forInvisibilityOfElementLocated(driver, By.xpath(DMConstants.LOGIN_PAGE_STATUS_AUTHENTICATION_FAILED), 30);
		
		// Making sure fields are emptied or for domain name, it contains "composite".
		assertTrue(loginPage.getDomainElement().getAttribute("value").equals(DMConstants.DOMAINNAME), "Domain name field does not contain the default domain (composite).");
		assertTrue(loginPage.getUsernameElement().getAttribute("value").isEmpty(), "Username field is not emptied when it should.");
		assertTrue(loginPage.getPasswordElement().getAttribute("value").isEmpty(), "Password field is not emptied when it should.");

		// Check for focus input field
		WebElement focusElem = loginPage.getFocusedElement();	
		assertTrue(loginPage.getUsernameElement().equals(focusElem), "Focus is not on the username field.");

		// Now login with bad use name
		logger.info("Test invalid login with bad username.");
		loginPage.login(DMConstants.DOMAINNAME, "BadUser", DMConstants.PASSWORD);

		msgElem = driver.findElement(By.cssSelector(DMConstants.LOGIN_PAGE_MESSAGE));
		Wait.forElementVisibility(driver, msgElem, 15);
		
		assertTrue(msgElem.getText().contains(
				DMConstants.ASSERT_TEXT_INVALID_CREDENTIAL),
				DMConstants.SYSOUT_MSG_PLEASE_REENTER_CREDENTIALS_NOT_DISPLAYED);

		Wait.forInvisibilityOfElementLocated(driver, By.xpath(DMConstants.LOGIN_PAGE_STATUS_AUTHENTICATION_FAILED), 30);

		// Now login with bad domain name
		logger.info("Test invalid login with bad domain name.");
		loginPage.login("BadDomain", DMConstants.USERNAME, DMConstants.PASSWORD);

		msgElem = driver.findElement(By.cssSelector(DMConstants.LOGIN_PAGE_MESSAGE));
		Wait.forElementVisibility(driver, msgElem, 15);
		
		assertTrue(msgElem.getText().contains(
				DMConstants.ASSERT_TEXT_INVALID_CREDENTIAL),
				DMConstants.SYSOUT_MSG_PLEASE_REENTER_CREDENTIALS_NOT_DISPLAYED);

		Wait.forInvisibilityOfElementLocated(driver, By.xpath(DMConstants.LOGIN_PAGE_STATUS_AUTHENTICATION_FAILED), 30);

		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-1, DM-12, DM-595")
	public void validLogin() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);
		
		LoginPage loginPage = new LoginPage(this.driver, this.siteUrl);
		loginPage.get();
		
		loginPage.login(DMConstants.DOMAINNAME, DMConstants.USERNAME, DMConstants.PASSWORD);

		HomePage homePage = new HomePage(driver, this.siteUrl);
		homePage.get();
		
		// assert whether user logged
		assertTrue(driver.findElement(By.linkText(DMConstants.LINK_LOGOUT)).getText().contains(DMConstants.LINK_LOGOUT),
				DMConstants.SYSOUT_MSG_LOGIN_FAILED);
		
		homePage.logout();
		logger.info(methodName+": Success.");
	}

	//@Test(description="Test case DM-???", priority=5)
	public void headerLinks() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);
		
		LoginPage loginPage = new LoginPage(this.driver, this.siteUrl);
		loginPage.get();
		
		loginPage.login(DMConstants.DOMAINNAME, DMConstants.USERNAME, DMConstants.PASSWORD);

		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();
		
		logger.info(DMConstants.SYSOUT_MSG_CLICKING_THE_LINK_SITES);
		DMUtils.dmWait(2000);
		homePage.navigateToSites();
		logger.info(DMConstants.SYSOUT_MSG_CLICKING_THE_LINK_PLAN);
		DMUtils.dmWait(2000);
		homePage.navigateToPlans();
		logger.info(DMConstants.SYSOUT_MSG_CLICKING_THE_LINK_ADMIN);
		DMUtils.dmWait(2000);
		homePage.navigateToAdmin();
		DMUtils.dmWait(2000);
		
		homePage.logout();
		logger.info(methodName+": Success.");
	}
	
}
