package com.cisco.dm.sites;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.cisco.dm.HomePage;
import com.cisco.dm.LoginPage;
import com.cisco.dm.dialogbox.AddSiteDialogbox;
import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DriverFactory;

public class SitePageTests {
	private WebDriver driver = null;
	private String siteUrl;
	private HomePage homePage;
    private static final Logger logger = LogManager.getLogger("SitePageTests");

	@Parameters({ "browser" })
	@BeforeClass
	public void init(String browser) throws Exception {
		logger.info("Starting Site Page Tests...");

		this.driver = DriverFactory.initDriver(browser);
	}

	@AfterClass
	public void closeWebDriver() throws Exception {
		driver.close();
		driver.quit();
	}

	@Parameters({ "siteURL" })
	@BeforeMethod
	public void login(String siteURL) throws InterruptedException {
		// logged into site
		this.siteUrl = siteURL;
		LoginPage loginPage = new LoginPage(this.driver, siteURL);
		loginPage.get();
		loginPage.login(DMConstants.DOMAINNAME, DMConstants.USERNAME,
				DMConstants.PASSWORD);

		homePage = new HomePage(this.driver, siteURL);
		homePage.get();
		
		// navigate to sites page
		homePage.selectSites();
	}

	@AfterMethod
	public void logout() throws InterruptedException {
		homePage.logout();
	}

	@Test(dependsOnMethods = "addSite", description="Test case DM-18")
	public void duplicateSite() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);

		SitePage sitePage = new SitePage(this.driver, this.siteUrl);
		sitePage.get();
		
		sitePage.selectAdd();
		AddSiteDialogbox addSiteDialog = new AddSiteDialogbox(this.driver, this.siteUrl);
		addSiteDialog.get();
		
		addSiteDialog.setHost("localhost");
		addSiteDialog.setPort("9400");
		addSiteDialog.setName("localhost_9400");
		addSiteDialog.setDomain("composite");
		addSiteDialog.setUser("admin");
		addSiteDialog.setPassword("admin");
		
		// Validation
		// Where there is an error on duplicate site, the name is the determining factor.
		// If the conflict is on the site name, the input element will have red highlighting
		// color surrounding the input text and the size is small than the other valid
		// input text. The small size allow the page to show the error icon to the right
		// of the input. We will check for the size since all inputs have the error image.
		// For valid input, the image is hidden by the full size of the input. Full size
		// input has width of 146px.
		String style = addSiteDialog.getNameElement().getAttribute("style");
		String[] widthStyle = style.split(":");
		int index = widthStyle[1].lastIndexOf("px");
		int width = Integer.valueOf(widthStyle[1].trim().substring(0, index-1));
		Assert.assertTrue(width < 146, "Error: Site name field does not have error indicator set.");
		
		addSiteDialog.selectCancel();

		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-15")
	public void addSite() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);

		SitePage sitePage = new SitePage(this.driver, this.siteUrl);
		sitePage.get();

		try {
			sitePage.getSiteElement("localhost_9400");
			
			// Remove previous add site item.
			sitePage.deleteSite("localhost_9400");
		} catch (NoSuchElementException nsee) { }
		
		int siteCount = sitePage.getSiteCount();
		
		// add sites
		sitePage.addSite(DMConstants.HOSTVALUE_LOCALHOST,
				DMConstants.PORT_VALUE_9400.toString(), DMConstants.DOMAINNAME,
				DMConstants.USERNAME, DMConstants.PASSWORD,
				DMConstants.ANNOTATION_VALUE);

		// validation
		Assert.assertTrue(sitePage.getSiteCount() == (siteCount+1),
				"Error: Add site did not complete successfully. Site count did not match.");
		logger.info(methodName+": Success.");
	}

	@Test(dependsOnMethods = "addSite", priority = 5, description="Test case DM-22")
	public void deleteSite() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);

		SitePage sitePage = new SitePage(this.driver, this.siteUrl);
		//sitePage.get();

		sitePage.deleteSite(DMConstants.HOSTVALUE_LOCALHOST + "_"
				+ DMConstants.PORT_VALUE_9400);

		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-15")
	public void cancelAddSite() {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);

		SitePage sitePage = new SitePage(this.driver, this.siteUrl);
		sitePage.get();

		WebElement addButton = driver.findElement(By.xpath(DMConstants.SITE_PAGE_ADD_BUTTON));
		addButton.click();

		AddSiteDialogbox addSiteDialogbox = new AddSiteDialogbox(driver, this.siteUrl);
		addSiteDialogbox.get();

		addSiteDialogbox.sendKeys(driver.findElement(By.cssSelector(DMConstants.DIALOGBOX_ADD_SITE_HOST)),
				DMConstants.HOSTVALUE_LOCALHOST, true);
		addSiteDialogbox.sendKeys(driver.findElement(By.cssSelector(DMConstants.DIALOGBOX_ADD_SITE_PORT)),
				DMConstants.PORT_VALUE_9400.toString(), true);
		addSiteDialogbox.sendKeys(driver.findElement(By.cssSelector(DMConstants.DIALOGBOX_ADD_SITE_DOMAIN)),
				DMConstants.DOMAINNAME, true);
		addSiteDialogbox.sendKeys(driver.findElement(By.cssSelector(DMConstants.DIALOGBOX_ADD_SITE_USER)),
				DMConstants.USERNAME, true);
		addSiteDialogbox.sendKeys(driver.findElement(By.cssSelector(DMConstants.DIALOGBOX_ADD_SITE_PASSWORD)),
				DMConstants.PASSWORD, true);
		addSiteDialogbox.sendKeys(driver.findElement(By.cssSelector(DMConstants.DIALOGBOX_ADD_SITE_ANNOTATION)),
				DMConstants.ANNOTATION_VALUE, true);

		addSiteDialogbox.selectCancel();
		
		logger.info(methodName+": Success.");
	}
}
