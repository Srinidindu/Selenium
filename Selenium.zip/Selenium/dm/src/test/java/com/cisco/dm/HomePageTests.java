package com.cisco.dm;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.cisco.dm.dialogbox.ConfirmLogoutDialogbox;
import com.cisco.dm.dialogbox.DownloadBackupFileDialogbox;
import com.cisco.dm.dialogbox.RestoreDialogbox;
import com.cisco.dm.sites.SitePage;
import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DMUtils;
import com.cisco.dm.util.DriverFactory;
import com.cisco.dm.util.Wait;

/**
 * Home page testing
 * 
 * @author nochin
 * 
 */
public class HomePageTests {
    private static final Logger logger = LogManager.getLogger("HomePageTests");
    
	private WebDriver driver = null;
	String siteUrl;
	HomePage homePage;

	@BeforeClass
	public void init() throws Exception {
		logger.info("Starting Home Page Tests...");
	}

	@Parameters({ "browser", "siteURL" })
	@BeforeMethod
	public void login(String browser, String siteURL) throws Exception {
		this.driver = DriverFactory.initDriver(browser);
		this.siteUrl = siteURL;
		
		// Initialize Page
		LoginPage loginPage = new LoginPage(driver, siteURL);
		loginPage.get();

		// logged into site
		loginPage.login(DMConstants.DOMAINNAME, DMConstants.USERNAME,
				DMConstants.PASSWORD);
	}

	@Test(description="Test case DM-624")
	public void refreshPage() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);
		
		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();
		
		driver.navigate().refresh();
		
		// Need to do this because of refresh page otherwise page would be staled.
		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();

		// Validation
		Assert.assertEquals(homePage.getTitleElement().getText(), "Welcome admin");
		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-614")
	public void navigateBack() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);
		
		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();
		
		homePage.selectSites();

		SitePage sitePage = new SitePage(this.driver, this.siteUrl);
		sitePage.get();
		
		this.driver.navigate().back();

		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();
	
		// Validation
		Assert.assertTrue(homePage.getSitesCountDescriptionElement().getText().matches(".* sites? defined$"),
				"Error: Invalid description of Sites count.");
		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-657, DM-659, DM-639")
	public void validateHomePage() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);
		
		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();
		
		// Validation
		Assert.assertEquals(homePage.getTitleElement().getText(), "Welcome admin");
		
		// Validate manage site descriptions
		int count;
		try {
			count = Integer.valueOf(homePage.getSitesCountElement().getText());
		} catch (Exception e) {
			count = 0;
		}
		Assert.assertTrue(homePage.getSitesCountDescriptionElement().getText().matches(count+".* sites? defined$"),
					"Error: Invalid description of Manage Sites count.");
		
		if (count > 0)
			Assert.assertTrue(homePage.getSitesDescriptionElement().getText().matches("^You have sites defined.*"),
					"Error: Invalid Manage Sites description.");
		else
			Assert.assertTrue(homePage.getSitesDescriptionElement().getText().matches("^There are no sites defined.*"),
					"Error: Invalid Manage Sites description.");

		// Validate manage plans descriptions
		try {
			count = Integer.valueOf(homePage.getPlansCountElement().getText());
		} catch (Exception e) {
			count = 0;
		}
		Assert.assertTrue(homePage.getPlansCountDescriptionElement().getText().matches(count+".* plans? defined$"),
					"Error: Invalid description of Manage Plans count.");
		
		if (count > 0)
			Assert.assertTrue(homePage.getPlansDescriptionElement().getText().matches("^You have plans defined.*"),
					"Error: Invalid Manage Sites description.");
		else
			Assert.assertTrue(homePage.getPlansDescriptionElement().getText().matches("^There are no plans defined.*"),
					"Error: Invalid Manage Sites description.");

		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-714, DM-658")
	public void headerLinks() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);
		
		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();
		
		logger.info(DMConstants.SYSOUT_MSG_CLICKING_THE_LINK_SITES);
		homePage.selectSites();
		
		SitePage sitesPage = new SitePage(this.driver, this.siteUrl);
		sitesPage.get();
		
		// Validate
		Assert.assertEquals(sitesPage.getSiteListElement().getText(), "Site List", "Error: Invalid sites page.");

		logger.info(DMConstants.SYSOUT_MSG_CLICKING_THE_LINK_PLAN);
		DMUtils.dmWait(1000);
		homePage.selectPlans();
		
		// Uncomment this when plan page is done.
		//PlanPage plansPage = new PlanPage(this.driver, this.siteUrl);
		//plansPage.get();
		//Assert.assertEquals(sitesPage.getPlanListElement().getText(), "Plan List", "Error: Invalid plans page.");
		
		
		logger.info(DMConstants.SYSOUT_MSG_CLICKING_THE_LINK_ADMIN);
		DMUtils.dmWait(1000);
		homePage.navigateToAdmin();
		DMUtils.dmWait(1000);
		
		// Validate tabs are in sequence.
		WebElement sitesHeader = homePage.getSitesMenuElement();
		WebElement plansHeader = homePage.getPlansMenuElement();
		WebElement adminHeader = homePage.getAdminMenuElement();
		WebElement helpHeader = homePage.getHelpMenuElement();
		WebElement logoutHeader = homePage.getLogoutMenuElement();
		
		Assert.assertTrue(sitesHeader.getLocation().getX() < plansHeader.getLocation().getX(),
				"Error: Sites menu is not to the left of Plans menu.");
		Assert.assertTrue(plansHeader.getLocation().getX() < adminHeader.getLocation().getX(),
				"Error: Plans menu is not to the left of Admin menu.");
		Assert.assertTrue(adminHeader.getLocation().getX() < helpHeader.getLocation().getX(),
				"Error: Admin menu is not to the left of Help menu.");
		Assert.assertTrue(helpHeader.getLocation().getX() < logoutHeader.getLocation().getX(),
				"Error: Help menu is not to the left of Logout menu.");

		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-628")
	public void manageSites() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);

		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();

		Assert.assertTrue(homePage.getTitleElement().getText()
				.contains("Welcome"));
		// assert whether user logged

		Assert.assertTrue(
				homePage.getLogoutMenuElement().getText().contains("Logout"),
				DMConstants.ASSERT_TEXT_LINK_USER_LOGOUT_MSG);
		logger.info(DMConstants.SYSOUT_MSG_LOGGED_IN_SUCCESSFULLY);
		logger.info(DMConstants.SYSOUT_MSG_CLICKING_THE_MANAGE_SITES);

		homePage.selectSites();
		
		SitePage sitePage = new SitePage(this.driver, this.siteUrl);
		sitePage.get();
		
		// Manage site page validation.
		Assert.assertEquals(sitePage.getSiteListElement().getText(), "Site List",
				"Error: Invalid site page found.");
		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-629")
	public void managePlans() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);

		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();

		// assert whether user logged
		Assert.assertTrue(
				homePage.getLogoutMenuElement().getText().contains("Logout"),
				DMConstants.ASSERT_TEXT_LINK_USER_LOGOUT_MSG);
		logger.info(DMConstants.SYSOUT_MSG_LOGGED_IN_SUCCESSFULLY);
		logger.info(DMConstants.SYSOUT_MSG_CLICKING_THE_MANAGE_PLANS);
		homePage.selectPlans();

		//PlanPage planPage = new PlanPage(this.driver, this.siteUrl);
		//planPage.get();
		
		// TODO:: Need to validate that we are on manage plans page.
		//Assert.assertEquals(planPage.getPlanListElement().getText(), "Plan List",
		//		"Error: Invalid manage plans page found.");

		this.driver.navigate().back();

		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();
	
		// Validation
		Assert.assertTrue(homePage.getPlansCountDescriptionElement().getText().matches(".* plans? defined$"),
				"Error: Invalid description of Manage Plans count.");
		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-637")
	public void resizeScreen() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);

		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();
		logger.info(methodName+": Success.");
		
		// resizing. Note: minimize window is OS specific so it is not tested here.
		Dimension currentSize = this.driver.manage().window().getSize();
		this.driver.manage().window().setSize(new Dimension(currentSize.width/2, currentSize.height/2));
		DMUtils.dmWait(2000);	// Delay for display purpose
		
		// Move to new position test
		this.driver.manage().window().setPosition(new Point(100, 100));
		DMUtils.dmWait(2000);	// Delay for display purpose
		
		this.driver.manage().window().setPosition(new Point(200, 200));
		DMUtils.dmWait(2000);	// Delay for display purpose
		
		this.driver.manage().window().setPosition(new Point(300, 300));
		DMUtils.dmWait(2000);	// Delay for display purpose

		// Maximized test.
		this.driver.manage().window().maximize();

		DMUtils.dmWait(2000);	// Delay for display purpose
		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-662")
	public void logoutConfirmation() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);

		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();
		
		// Validation
		Assert.assertEquals(homePage.getTitleElement().getText(), "Welcome admin");
		DMUtils.dmWait(1000);	// Delay for display purpose

		homePage.getLogoutMenuElement().click();
		
		ConfirmLogoutDialogbox confirm = new ConfirmLogoutDialogbox(this.driver, this.siteUrl);
		confirm.get();
		
		Assert.assertEquals(confirm.getMessageElement().getText(), "Are you sure you want to logout?",
				"Error: Confirm message is not what is expected.");

		confirm.selectYes();
		DMUtils.dmWait(1000);	// Delay for display purpose

		LoginPage loginPage = new LoginPage(this.driver, this.siteUrl);
		loginPage.get();
		 
		Assert.assertTrue(loginPage.getUsernameElement().equals(loginPage.getFocusedElement()),
				"Error: We are not in login page.");

		loginPage.login(DMConstants.DOMAINNAME, DMConstants.USERNAME,DMConstants.PASSWORD);

		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();
		
		// Test logout with No confirmation
		homePage.getLogoutMenuElement().click();
		
		confirm = new ConfirmLogoutDialogbox(this.driver, this.siteUrl);
		confirm.get();
		confirm.selectNo();
		
		DMUtils.dmWait(1000);	// Delay for display purpose
		
		logger.info(methodName+": Success.");
	}

	@Test(description="Test case DM-715, DM-716, DM-717")
	public void adminMenu() throws Exception {
	    class Local {};
	    String methodName = Local.class.getEnclosingMethod().getName();
		logger.info("Testing "+methodName);
		
		homePage = new HomePage(this.driver, this.siteUrl);
		homePage.get();
		
		WebElement adminMenu = homePage.getAdminMenuElement();
		homePage.performMove(adminMenu);
		
		// DM-715
		// Validate that menu items below the Amin menu is visible.
		Wait.forVisibilityLocatedBy(this.driver, By.linkText(DMConstants.HEADER_MENU_ITEM_TEXT_BACKUP), 15);
		Assert.assertTrue(this.driver.findElement(By.linkText(DMConstants.HEADER_MENU_ITEM_TEXT_BACKUP)).isDisplayed(),
				"Error: Backup menu item is not visible.");
		Assert.assertTrue(this.driver.findElement(By.linkText(DMConstants.HEADER_MENU_ITEM_TEXT_RESTORE)).isDisplayed(),
				"Error: Restore menu item is not visible.");

		// DM-716
		homePage.selectAdminMenu(DMConstants.HEADER_MENU_ITEM_TEXT_BACKUP);
		
		DownloadBackupFileDialogbox backupDialog = new DownloadBackupFileDialogbox(this.driver, this.siteUrl);
		backupDialog.get();
		
		Assert.assertTrue(backupDialog.getTitleElement().getText().equals(DMConstants.DIALOGBOX_BACKUP_TEXT_TITLE), 
				"Error: Invalid Download Backup dialogbox title.");
		
		DMUtils.dmWait(2000);	// Delay for display purpose
		backupDialog.selectCancel();

		// DM-717
		homePage.selectAdminMenu(DMConstants.HEADER_MENU_ITEM_TEXT_RESTORE);
		RestoreDialogbox restoreDialog = new RestoreDialogbox(this.driver, this.siteUrl);
		restoreDialog.get();
		Assert.assertTrue(restoreDialog.getTitleElement().getText().equals(DMConstants.DIALOGBOX_RESTORE_TEXT_TITLE), 
				"Error: Invalid Restore dialogbox title.");
		
		DMUtils.dmWait(2000);	// Delay for display purpose
		restoreDialog.selectCancel();

		logger.info(methodName+": Success.");
	}

	@AfterMethod
	public void closeWebDriver() throws Exception {
		logger.info("Logging out.");
		homePage.logout();
		DMUtils.closeDriver(driver);
	}

	@AfterClass
	public void tearDown() {
	}
}
