package com.cisco.dm.sites.resourcemapping;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import com.cisco.dm.DMPage;
import com.cisco.dm.HomePage;
import com.cisco.dm.LoginPage;
import com.cisco.dm.sites.SitePage;
import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DMUtils;
import com.cisco.dm.util.DriverFactory;

public class ResourceMappingTests {

	private WebDriver driver = null;
	HomePage homePage;
	public static Logger logger = Logger.getLogger(ResourceMappingTests.class);

	@Parameters({ "browser", "siteURL" })
	@BeforeMethod
	public void init(String browser, String siteURL) throws Exception {
		this.driver = DriverFactory.initDriver(browser);
		// Initialize Pages
		LoginPage loginPage = new LoginPage(driver, siteURL);
		loginPage.get();

		// logged into site
		loginPage.login(DMConstants.DOMAINNAME, DMConstants.USERNAME,
				DMConstants.PASSWORD);
		// navigate to sites page
		HomePage homePage = new HomePage(driver, "");
		homePage.navigateToSites();
		Thread.sleep(2000);
	}

	@Test
	public void testResourceMapping() throws Exception {
		// create source site
		SitePage sitePage = new SitePage(this.driver,
				"https://localhost:9402/deploy/#sites");

		// add sites - source
		sitePage.addSite(DMConstants.HOSTVALUE_LOCALHOST,
				DMConstants.PORT_VALUE_9400.toString(), DMConstants.DOMAINNAME,
				DMConstants.USERNAME, DMConstants.PASSWORD,
				DMConstants.ANNOTATION_VALUE);
		Thread.sleep(3000);

		// add resource bundle
		DMPage.addResourceBundle(driver, DMConstants.RESOURCE_BUNDLE_NAME,
				DMConstants.RESOURCE_BUNDLE_ANNOTATION);
		Thread.sleep(1000);

		// add resource to resource bundle
		DMPage.addResourceToResourceBundle(driver, DMConstants.RESOURCE_PATH,
				DMConstants.RESOURCE_BUNDLE_NAME);
		Thread.sleep(4000);

		// add sites - target
		sitePage.addSite(DMConstants.HOSTVALUE_LOCALHOST,
				DMConstants.TARGET_PORT_VALUE.toString(),
				DMConstants.DOMAINNAME, DMConstants.USERNAME,
				DMConstants.PASSWORD, DMConstants.ANNOTATION_VALUE);
		Thread.sleep(3000);

		// click on Resource Mapping
		sitePage.navigateToResourceMappingsTab();

		// Select Oracle 11 GR2
		// click on Add Target Site
		sitePage.selectSite("localhost_9400");
		ResourceMapping resourceMapping = new ResourceMapping(driver, "");
		resourceMapping.selectOracleSourceResource();
		resourceMapping.clickAddTargetSite();
		resourceMapping.editMapping("/shared/Source_RS/Oracle11GR2");

		// navigate to plan
		HomePage homePage = new HomePage(driver, "");
		homePage.navigateToPlans();

		// create plan
		DMPage.addPlan(driver, DMConstants.MIGRATE_PLAN_NAME,
				DMConstants.MIGRATE_PLAN_DESCRIPTION,
				DMConstants.SOURCE_HOSTVALUE_LOCALHOST + '_'
						+ DMConstants.SOURCE_PORT_VALUE,
				DMConstants.TARGET_HOSTVALUE_LOCALHOST + '_'
						+ DMConstants.TARGET_PORT_VALUE);

		// add migrate operation
		DMPage.addMigrateOperation(driver, DMConstants.MIGRATE_PLAN_NAME,
				DMConstants.RESOURCE_BUNDLE_NAME,
				DMConstants.MIGRATE_TARGET_RESOURCE_PATH);

		// execute plan
		DMPage.executePlan(driver, DMConstants.MIGRATE_PLAN_NAME);
		Thread.sleep(20000);

		// validation
		  validate();
	}
 
	
	private void validate() throws Exception {
		homePage = new HomePage(this.driver,
				"https://localhost:9402/deploy/#sites");
		Thread.sleep(7000);
		homePage.navigateToSitesTab();
		// navigate to sites page
		Thread.sleep(7000);
		SitePage sitePage = new SitePage(driver, "");
		Thread.sleep(7000);
		sitePage.selectSite(DMConstants.TARGET_HOSTVALUE_LOCALHOST + "_"
				+ DMConstants.TARGET_PORT_VALUE);
		Thread.sleep(5000);
		sitePage.navigateToResourceBundlesTab();
		Thread.sleep(5000);
	
		DMUtils.doubleClick(driver,
				driver.findElement(By.xpath(".//div[@title='shared']")));

		Thread.sleep(5000);
		Assert.assertTrue(
				driver.findElement(By.xpath(".//div[@title='Source_RS']"))
						.isDisplayed(), "Source_RS not visible");
		//homePage.navigateToSitesTab();
}
	

	private String getResourceNodeXpath(String resourceName) {
		return new StringBuffer(DMConstants.XPATH_VALIDATE_RESOURCE_NODE)
				.replace(
						DMConstants.XPATH_VALIDATE_RESOURCE_NODE.indexOf("<"),
						DMConstants.XPATH_VALIDATE_RESOURCE_NODE.indexOf(">") + 1,
						resourceName).toString();

	}

	
	@AfterClass
	public void tearDown() throws Exception {

		SitePage sitePage = new SitePage(driver, "");
		sitePage.deleteSite(DMConstants.SOURCE_HOSTVALUE_LOCALHOST + "_"
				+ DMConstants.SOURCE_PORT_VALUE);

		sitePage.deleteSite(DMConstants.TARGET_HOSTVALUE_LOCALHOST + "_"
				+ DMConstants.TARGET_PORT_VALUE);

		driver.quit();

	}
}
