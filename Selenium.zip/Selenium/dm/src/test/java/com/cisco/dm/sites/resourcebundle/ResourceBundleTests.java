package com.cisco.dm.sites.resourcebundle;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import com.cisco.dm.DMPage;
import com.cisco.dm.HomePage;
import com.cisco.dm.LoginPage;
import com.cisco.dm.sites.SitePage;
import com.cisco.dm.util.DMConstants;
import com.cisco.dm.util.DriverFactory;

public class ResourceBundleTests {

	private WebDriver driver = null;
	HomePage homePage;
	public static Logger logger = Logger.getLogger(ResourceBundleTests.class);

	@BeforeClass
	@Parameters({ "browser", "siteURL" })
	public void init(@Optional String browser, @Optional String siteURL)
			throws Exception {

		// String browser, siteURL;
		if (browser == null) {
			browser = "chrome";
		}

		if (siteURL == null) {
			siteURL = "https://localhost:9402/deploy/";
		}

		this.driver = DriverFactory.initDriver(browser);
		// Initialize Pages
		LoginPage loginPage = new LoginPage(driver, siteURL);
		loginPage.get();

		// logged into site
		loginPage.login(DMConstants.DOMAINNAME, DMConstants.USERNAME,
				DMConstants.PASSWORD);
		// navigate to sites page
		HomePage homePage = new HomePage(driver, "");
		homePage.navigateToSites();
		Thread.sleep(2000);
		// add sites

		SitePage sitePage = new SitePage(this.driver, siteURL);
		sitePage.get();

		// add sites
		sitePage.addSite(DMConstants.HOSTVALUE_LOCALHOST,
				DMConstants.PORT_VALUE_9400.toString(), DMConstants.DOMAINNAME,
				DMConstants.USERNAME, DMConstants.PASSWORD,
				DMConstants.ANNOTATION_VALUE);
		Thread.sleep(3000);
	}

	@Test(description = "DM-652: Add resource bundle")
	public void testAddResourceBundle() throws Exception {
		// add bundle
		DMPage.addResourceBundle(driver, DMConstants.RESOURCE_BUNDLE_NAME,
				DMConstants.RESOURCE_BUNDLE_ANNOTATION);
	}

	@Test(dependsOnMethods = "testAddResourceBundle")
	public void testAddResourceToResourceBundle() throws Exception {
		// add resource to resource bundle
		DMPage.addResourceToResourceBundle(driver, DMConstants.RESOURCE_PATH,
				DMConstants.RESOURCE_BUNDLE_NAME);
	}

	//@Test(description = "DM-113:Resource path in bundle")
	public void testResourcePathinBundle() throws Exception {
		// add bundle
		DMPage.addResourceBundle(driver, DMConstants.RESOURCE_BUNDLE_NAME,
				DMConstants.RESOURCE_BUNDLE_ANNOTATION);

		// add resource to resource bundle
		DMPage.addResourceToResourceBundle(driver, DMConstants.RESOURCE_PATH,
				DMConstants.RESOURCE_BUNDLE_NAME);

		// Getting Resource Bundle path
		ResourceBundle resBundle = new ResourceBundle(driver, "");
		String actResBundlePath = resBundle.getResourceBundlePath();
		Assert.assertEquals(actResBundlePath, "/shared/Source_RS");
	}

	//@Test(description = "DM-108:copy button for bundles page")
	public void testCopyResourceBundle() throws Exception {
		// add bundle
		DMPage.addResourceBundle(driver, DMConstants.RESOURCE_BUNDLE_NAME,
				DMConstants.RESOURCE_BUNDLE_ANNOTATION);

		// add resource to resource bundle
		DMPage.addResourceToResourceBundle(driver, DMConstants.RESOURCE_PATH,
				DMConstants.RESOURCE_BUNDLE_NAME);

		//click on Copy Bundle
		ResourceBundle resBundle = new ResourceBundle(driver, "");
		
		//verify if a new resource bundle is created with an "_copy"
	}

	@AfterClass
	public void tearDown() throws Exception {
		SitePage sitePage = new SitePage(driver, "");
		sitePage.deleteSite(DMConstants.HOSTVALUE_LOCALHOST + "_"
				+ DMConstants.PORT_VALUE_9400);
		Thread.sleep(3000);
		driver.quit();
	}

}
